<center><table summary="Input fields table">

<tr>
<th align="right"></th>
<td></td>

<td></td>

<td></td>
</tr>

<tr>
<th align="right"><?php $form->AddLabelPart(array("FOR"=>"start")); ?>:</th>
<td><?php 
$form->AddInputPart("start"); ?>
</td>

</tr>

<tr>
<td colspan="4" align="center"> <?php $form->AddInputPart("action"); ?></td>
</tr>

</table>
</center>
