<?php
/*
This new version of the little toy, at 19 november 2005, let you to set as link not all days of the week
NB: THERE IS A LITTLE BUG IN THE CORE JAVASCRIPT: SOMETIME , in the previous month, the days linkable are not
active;

please report any other bug or problem at andreabersi@gmail.com

Ciao

Andrea Bersi
AOSTA (ITALY)
http://abmcr.altervista.org

*/


/********************************************
ADAPTATION NOTES AND EXAMPLES

This is a wonderful piece of software, but I use Manuel Lamos'
Form Generation and validation class.

I don't feel confortable with the date plugin so when I sow Andrea' work
I decided to port it in a plugin fashion

All the merit for the class goes to Andrea Bersi as above


The main changes in the class are as follows:
- it accepts SQL formatted date (p.e. 2005-11-19)
- in the output is included an hidden field preformatted in SQL ready to use.
  That required to add a simple function to the javascript file, the field
  displays the date in the desired formatting
- introduced the requested methods to suite to Manuel's form_custom_class

Here is an implementation example and the parameters the control accepts

	require_once("classes/cal_class.php");
	
	$form->AddInput(array(
		"TYPE"=>"custom",
		"NAME"=>"born",
		"ID"=>"born",
		"CustomClass"=>"form_calendar_class",
		"STARTDATE"=>"2005-2-12",	// lowest acceptable value: default no limit
		"ENDDATE"=>"today",		// highest acceptable value default no limit
						// magic "today" in any date definition
						// parametr sets the value to today
		"LABEL"=>"Bith's date",		// the control label
		"VALUE"=>"2005-11-27",		// date in SQL format
		"VALIDDAYS"=>"1,2,3",		// means Mon Tue Wen are valid days
						// 0= Sunday 6=Saturday
						// default: all week is valid
		"Accessible"=>0,		// 0 = non editable 1=editable default 0
		"LANG"=>"en",			// language for the calendar
						// valid are "it" (default) for
						// italian and "en" for english
		"FORMAT"=>"1",			// date format: 1 = MM/DD/YYY
						// 2 (defaulr) = DD/MM/YYY
						// when you set LANG it defaults to
						// the correct diplay "it" (default) for
						// DD/MM/YYYY display and "en" for
						// MM/DD/YYYY
	"SELBG"=>"Green",			// today's background color default Green
	"MONTHBG"=>"Red",			// month's name background color
	"MONTHTX"=>"White",			// month's name text color
	"WEEKBG"=>"Orange",			// week's name background color
	"WEEKTX"=>"Green",			// week's name text color
	"TODAY"=>"Yellow",			// today's higlight color
	"OFFMONTH"=>"AntiqueWhite",		// off month days color
	"WEEKEND"=>"LightGray",			// weekend's highlight color
	"CLASS"=>"theCSSClass",			// CSS class for the input field
	"OPTIONAL"=>1,				// is the field optional? 0=no=default - 1 = yes
	"NotEmptyErrorMessage"=>"Your text",	// text for validation failure
	"NotEmpty"=>1				// 0 = no = default - 1 = yes
	"InvalidStartMessage"=>"Your custom start error message",
	"InvalidEndMessage"=>"Your custom end error message",
	"CalendarIcon"=>"images/icons/b_calendar.png"	// complete path to the image to be displayed
												// instead of button
												// if not specified a button will be displayed
	));

	You can take off the SQL parameter from the $_POST as
	_sql___{your-field-name}_calendar
	
	p.e. in case the NAME is "birth" the SQL param will be
	_sql__birth_calendar
	    ^^
	Please pay attention to the fact that after _sql there are 2
	underscores
	
	Alessandro Bianchi
	19-9-2005
	alex at skynet-srl.com
	
	
	12-10-2005
	Fixed a bug that caused the selection button to be displayed even if
	Accessible was set to 0
	
	30-4-2006
	New rewrite
	The class now implements the validateInput method and is strictly
	coherent with the forms'  class.
	Added a new static variablie to automagically detect the need to include the
	javascript that is now embedded in the same file.
	Added icon for display purposes (you may change it if you like);
	The Javascript is only outputted at display time, so you can safely require
	
	30-4-2006
	Fixed button display even if Accessible was set to false
	Introduced js validation on lenght if AllowManual = true;
***********************************************/
require_once ("forms.php");

class form_calendar_class extends form_custom_class
{
  
  const	VERSION = "2.1 1-5-2006";
  public $lang="it";			// valid are "it" and "en"
  public $date_format=1;			// 1 = mm/dd/aaa 2=dd/mm/aaaa
  public $name="";				// the name of the control
  public $label="";			// the label
  public $curVal="";			// the current value;
  public $startDate="";			// the start date for the calendar
  public $endDate="";			// the end date for the calendar
  //public $validationErrorMessage;		// validation error message
  // developement publics
  public $optional=0;
  private $invalid_start_error_message="";
  private $invalid_end_error_message="";
  public $Accessible =1;			// internal public
  
  public $form;				// the form  we are living in
  //public $readOnly=0;			// is the control readonly?
  public $applica ="";		// Apply default text
  public $annulla ="";		// Cancel default text
  
  public $format="{calendar}{sqlCalendar}{btnCalendar}";
  //localisation publiciable
  public $day_lang;
  public $month_lang;
  public $short_month_lang;
  // layout publiciable
  //publiciable needed by the graphic output
  public $sfondo_day_selected="Green"; //background of the day today
  public $grandezza_carattere="XX-Small"; //size of the text
  public $sfondo_mese="Blue"; //background of the month at the top
  public $testo_mese="White"; //color of the text of Month
  public $sfondo_settimana="Orange"; //background of the week at the top
  public $testo_settimana="Green";//color of the text of the days of Week
  public $colore_oggi="Yellow";//background of the day selected
  public $sfondo_giorniNonDelMese="AntiqueWhite";//background of the daysof next and previous month
  public $sfondo_giorniWeekEnd="LightGray"; //background of the days of week end
  public $giorni_settimana_linkabili="0,1,2,3,4,5,6";// set the day of the week as linkable; 0--> sunday to 6-->saturday
  private $allowManual = false;		// flag to enable user manual input - 
  									// true= manual alowed
  									// false = manual not allowed
  private $calID=null;				// unique object id
  private $sqlID=null;				// SQL hidden field id
  private $btnID=null;				// push button id
  public $client_validate=1;			
  public $server_validate=1;
  private $icon = null;				// URL of the icon to be shown for
  									// button
  
  static $JS_DONE = false;
  
  function AddInput(&$form, $arguments)
  {
	$this->form = $form;
	$this->calID=$this->GenerateInputID($form, $this->input, "calendar");
	$this->sqlID=$this->GenerateInputID($form,$this->input,"sqlCalendar");
	$this->btnID=$this->GenerateInputID($form,$this->input,"test");
	
	$this->giorni_settimana_linkabili=(IsSet($arguments["VALIDDAYS"]) ? $arguments["VALIDDAYS"] : $this->giorni_settimana_linkabili);
	$this->name=(IsSet($arguments["NAME"]) ? $arguments["NAME"] : $this->name);
	$this->label=(IsSet($arguments["LABEL"]) ? $arguments["LABEL"] : "");
	//$this->readOnly=(IsSet($arguments["READONLY"]) ? $arguments["READONLY"] : $this->readOnly);
	
	//$this->showBtn=(IsSet($arguments["ShowBtn"]) ? $arguments["ShowBtn"] : $this->showBtn);
	
	$this->lang=(IsSet($arguments["LANG"]) ? $arguments["LANG"] : $this->lang);
	switch ($this->lang)
	{
		case "it":
		$this->day_lang="'l','m','m','g','v','s','d'";
		$this->month_lang="'gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'";
		$this->short_month_lang="'gen','feb','mar','apr','mag','giu','lug','ago','set','ott','nov','dic'";
		$this->date_format=2;
		$this->applica="OK";
		$this->annulla="Annulla";
		$this->validationErrorMessage="Occorre fornire una data";
		$this->invalid_start_error_message="La data inserita e\'  inferiore al minimo accettato" ;
		$this->invalid_end_error_message="La data inserita e\' superiore al massimo accettato";
 
		break;
		case "en":
		$this->day_lang="'m','t','w','t','f','s','s'";
		$this->month_lang="'january','february','march','april','may','june','july','august','september','october','november','december'";
		$this->short_month_lang="'jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'";
		$this->date_format=1;
		$this->applica="OK";
		$this->annulla="Cancel";
		$this->validationErrorMessage="A valid date must be entered";
	//	$this->manualError="Date format should be MM/DD/AAAA";
		$this->invalid_start_error_message="Date is lower than mimum acceptable value";
		$this->invalid_end_error_message="Date is higher tha maximum acceptable value";
 
		break;
		//create your day_lang
	}
	
	$this->sfondo_day_selected=(isset($arguments["SELBG"]) ? $arguments["SELBG"] : $this->sfondo_day_selected);
	unset($arguments["SELBG"]);
	$this->sfondo_mese=(isset($arguments["MONTHBG"]) ? $arguments["MONTHBG"] : $this->sfondo_mese);
	unset($arguments["MONTHBG"]);
	$this->testo_mese=(isset($arguments["MONTHTX"]) ? $arguments["MONTHTX"] : $this->testo_mese);
	unset($arguments["MONTHTX"]);
	$this->sfondo_settimana=(isset($arguments["WEEKBG"]) ? $arguments["WEEKBG"] : $this->sfondo_settimana);
	unset($arguments["WEEKBG"]);
	$this->testo_settimana=(isset($arguments["WEEKTX"]) ? $arguments["WEEKTX"] : $this->testo_settimana);
	unset($arguments["WEEKTX"]);
	$this->colore_oggi=(isset($arguments["TODAY"]) ? $arguments["TODAY"] : $this->colore_oggi);
	unset($arguments["TODAY"]);
	$this->sfondo_giorniNonDelMese=(isset($arguments["OFFMONTH"]) ? $arguments["OFFMONTH"] : $this->sfondo_giorniNonDelMese);
	unset($arguments["OFFMONTH"]);
	$this->sfondo_giorniWeekEnd=(isset($arguments["WEEKEND"]) ? $arguments["WEEKEND"] : $this->sfondo_giorniWeekEnd);
	unset($arguments["WEEKEND"]);
	$this->curVal=(isset($arguments["VALUE"]) ? $arguments['VALUE'] : $this->curVal);
	$this->curVal=$this->setDate($this->curVal);
	unset($arguments["VALUE"]);
	$this->format=(isset($arguments["FORMAT"]) ? $arguments["FORMAT"] : $this->format);
	unset($arguments["FORMAT"]);
	$this->startDate= (isset($arguments["STARTDATE"]) ? $arguments["STARTDATE"] : "");
	$this->startDate=$this->setDate($this->startDate);
	unset($arguments["STARTDATE"]);
	$this->endDate= (isset($arguments["ENDDATE"]) ? $arguments["ENDDATE"] : "");
	unset($arguments["ENDDATE"]);
	$this->endDate=$this->setDate($this->endDate);
	$this->allowManual=(isset($arguments["AllowManual"]))?$arguments["AllowManual"]:false;
	unset($arguments["allowManual"]);
	
	
	$this->Accessible=isset($arguments['Accessible'])?$arguments['Accessible']:true;
	$this->invalid_start_error_message=(isset($arguments['InvalidStartMessage']))?$arguments['InvalidStartMessage']:$this->invalid_start_error_message;
	$this->invalid_start_error_message .= " ({$this->startDate})";
	$this->invalid_end_error_message=(isset($arguments['InvalidEndMessage']))?$arguments['InvalidEndMessage']:$this->invalid_end_error_message;
	$this->invalid_end_error_message.= " ({$this->endDate})";
	$this->icon=isset($arguments['CalendarIcon'])?$arguments['CalendarIcon']:null;
	
	unset($arguments["ID"]);
	unset($arguments["TYPE"]);
	unset($arguments["CustomClass"]);
	unset($arguments['CalendarIcon']);
	
	$this->optional=(isset($arguments["OPTIONAL"]) ? $arguments["OPTIONAL"] : $this->optional);
	
//	$sqlID="_sql_calendario".$this.calID;
	
	$this->valid_marks=array(
			"input"=>array(
				"calendar"=>"calendario".$this->calID,
				"sqlCalendar"=>$this->sqlID,
				"btnCalendar"=>$this->btnID
			)
		);
	
	$calendar_arguments=array(
				"NAME"=>$this->calID,
				"ID"=> "calendario".$this->calID,
				"TYPE"=>"text",
				"MAXLENGTH"=>10,
				"SIZE"=>10,
				"VALUE"=>$this->curVal,
				"ExtraAttributes"=> $this->allowManual==false?array( "readonly"=>"readonly"):array()
				);
	
	
	$hiddenSQL_arguments=array(
				"NAME"=>"_sql".$this->calID,
				"ID"=>$this->sqlID,
				"TYPE"=>"hidden",
				"VALUE"=>$this->sqlCurrent()
				);
	// <input type='button' name='calendario".$num."_calbutton' value=' ... ' id='calendario".$num."_calbutton' />
	
	$btn_arguments= array(
				"NAME"=>"calendario".$this->calID."_calbutton",
				"ID"=>$this->btnID
				);
	// determine if we are using icon or button
	if(strlen($this->icon) && file_exists($this->icon)&& $this->Accessible!=0)
	{
		$btn_arguments["TYPE"]="image";
		$btn_arguments["SRC"]=$this->icon;
		$btn_arguments["Accessible"]=false;
		$btn_arguments["ReadOnlyMark"]="<img src='{$this->icon}' >";
		
	//	$btn_arguments["ONCLICK"]="return false;";
	} else {
		$btn_arguments["TYPE"]="button";
		$btn_arguments["VALUE"]=" ";
	}
	
	
	/*
	 * if we are in manual mode, get sure we are going to setup hidden sql
	 * field
	 */ 
	if ($this->allowManual)
		$calendar_arguments["ONCHANGE"]="cleanSeparator(this);validateDate".$this->calID."();";
	
		// add field's properties
	
	$calendar_arguments=array_merge($calendar_arguments,$arguments);
	
	// add the "real" input fields
	
	if(strlen($error=$this->DefaultSetInputProperty($form, "Format", $this->format)))
			return($error);
	
	if(strlen($error=$form->AddInput($calendar_arguments)))
			return($error);
			
	if(strlen($error=$form->AddInput($hiddenSQL_arguments)))
			return($error);		
	if(strlen($error=$form->AddInput($btn_arguments)))
			return($error);			

  }
  
  
  //the function start with a defualt italian format of the date
  //function CreateCalendar($date_initial,$name,$link_back,$link_next,$date_format="2")
  function  AddInputPart(&$form)			// output del calndario vero e proprio
  {
    //date initial is the date visible in the textbox
    //name is the name of textbox containing the data selected: it is useful to set in for insert data into db
    //$link_back is the data in mm/dd/yyyy format of the date prev link
    //$link_next is the data in mm/dd/yyyy format of the date  link
    //date_format=1 then format date is mm/dd/yyyy
    //date_format=2 then format date is dd/mm/yyyy
    
    if ($this->date_format == 2)
    {
	    list ($giorno, $mese, $anno) = explode("/",$this->startDate);
	    $link_back= "'$mese/$giorno/$anno'";
	    
	    list ($giorno, $mese, $anno) = explode("/",$this->endDate);
	     $link_next = "'$mese/$giorno/$anno'";
	    
    }
    else
    {
	    $link_back = "'".$this->startDate."'";
	    $link_next = "'".$this->endDate."'";
    }
    
    
    $date_format = $this->date_format;
    $date_initial = $this->curVal;
   
    //echo $link_back ." - " . $link_next;
    $num = $this->calID;
    
   
		
		if ( $form->ReadOnly || $this->Accessible==0)
		{
			parent::AddInputPart($form);
			return;
		}
		
		 $this->outputJS();
		$calendario="";
		echo "<!-- CALENDAR START -->
	    <span id='calendario_outer$num' style='font-family:Arial;'>";
	 	parent::AddInputPart($form);
		$calendario.= "</span>
	    <script language='javascript'>
		calendario".$num."_outer_EnableHideDropDownFlag = false;
		calendario".$num."_outer_VisibleDate = scrivi_data_odierna(1);
	    function calendario".$num."_Up_SetClick(addClickTo)
	    {
	      if(addClickTo != '') document.getElementById(addClickTo).onclick = calendario".$num."_Up_CallClick;
	      document.onmousedown = CalendarPopup_Up_LostFocus;";

		if($this->allowManual==false)
			$calendario.="document.getElementById('calendario".$num."').onclick = calendario".$num."_Up_CallClick;";

		$calendario .="}
	    function calendario".$num."_Up_CallClick(e)
	    {
		var monthnames = new Array(".$this->month_lang.");
		var daynames = new Array(".$this->day_lang.");
		var day_week_link=new Array(".$this->giorni_settimana_linkabili.");
		CalendarPopup_Up_DisplayCalendar(day_week_link,'calendario".$num."_outer_EnableHideDropDownFlag', 'calendario".$num."','','','calendario".$num."_div', 'calendario".$num."_monthYear', 'calendario".$num."_Up_PreDisplayCalendar', 'calendario".$num."_Up_PreMonthYear', 'style=\"color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:Black;background-color:".$this->sfondo_giorniWeekEnd.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:Gray;background-color:".$this->sfondo_giorniNonDelMese.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:Black;background-color:".$this->colore_oggi.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:".$this->testo_mese.";background-color:".$this->sfondo_mese.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:Black;background-color:".$this->sfondo_settimana.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', 'style=\"color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', 'style=\"color:Black;background-color:".$this->sfondo_day_selected.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', 'style=\"color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', 'style=\"color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', $date_format, monthnames, daynames, 1, 6, 5, false, false, $link_back, $link_next,'".$this->btnId."',1, false, 'calendario".$num."_Up_PostBack', 0, 0, false, 'Annulla', false, 'Data oggi:', '', '', -1, 'calendario".$num."_outer_VisibleDate', 'Seleziona una data', CalendarPopup_Array_calendario".$num."_outer, '', '', '', '','".$this->sqlID."');
	    }
	    function calendario".$num."_Up_PreDisplayCalendar(theDate)
	    {
	      var monthnames = new Array(".$this->month_lang.");
	      var daynames = new Array(".$this->day_lang.");
	      var day_week_link=new Array(".$this->giorni_settimana_linkabili.");
	      CalendarPopup_Up_DisplayCalendarByDate(day_week_link,'calendario".$num."','','calendario".$num."_div', 'calendario".$num."_monthYear', 'calendario".$num."_Up_PreDisplayCalendar', 'calendario".$num."_Up_PreMonthYear', theDate, 'style=\"color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:Black;background-color:".$this->sfondo_giorniWeekEnd.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:Gray;background-color:".$this->sfondo_giorniNonDelMese.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:Black;background-color:".$this->sfondo_day_selected.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:White;background-color:".$this->sfondo_mese.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"','style=\"color:Black;background-color:".$this->sfondo_settimana.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', 'style=\"color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', 'style=\"color:Black;background-color:".$this->sfondo_day_selected.";font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', 'style=\"color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', 'style=\"color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:".$this->grandezza_carattere.";\"', $date_format, monthnames, daynames, 1, 6, 5, false, false, $link_back, $link_next, false, 'calendario".$num."_Up_PostBack', false, 'Annulla', false, 'Data oggi:', '', '', -1, 'calendario".$num."_outer_VisibleDate', 'Seleziona una data', CalendarPopup_Array_calendario".$num."_outer, '', '', '', '','".$this->sqlID."');	// added sqlID
	    }
		calendario".$num."_Up_SetClick('{$this->btnID}');
	    function calendario".$num."_Up_PreMonthYear(theDate)
	    {
		var monthnames = new Array(".$this->short_month_lang.");
		CalendarPopup_Up_DisplayMonthYear('calendario".$num."_div', 'calendario".$num."_monthYear', 'calendario".$num."_Up_PreDisplayCalendar', 'calendario".$num."_Up_PreMonthYear', monthnames, theDate, '".$this->applica."', '".$this->annulla."', $link_back, $link_next);
	    }
	    function calendario".$num."_Up_PostBack() {
	    }
	    var CalendarPopup_Array_calendario".$num."_outer = null;";
	    
	    if( $this->allowManual)
	    		$calendario .=" 
	    	function validateDate".$num."()
	    	{
	    		var mimum,maximum,current,dateArray; 
	    		
	    		obj=document.getElementById('calendario".$this->calID."');
	    		dateArray= obj.value.split('/');
	    		if(".$this->date_format."==2)
	    		{
	    			current=new Date(dateArray[2],dateArray[1]-1,dateArray[0]);	
	    			dateArray = '{$this->startDate}'.split('/'); 
	    			minimum = new Date(dateArray[2],dateArray[1],dateArray[0]);		
	    			dateArray = '{$this->endDate}'.split('/');
	    			maximum = new Date(dateArray[2],dateArray[1],dateArray[0]);	
	    		}
	    		else {
	    			current=new Date(dateArray[2],dateArray[0]-1,dateArray[1]);	
	    			dateArray = '{$this->startDate}'.split('/'); 
	    			minimum = new Date(dateArray[2],dateArray[0],dateArray[1]);	 
	    			dateArray = '{$this->endDate}'.split('/');
	    			maximum = new Date(dateArray[2],dateArray[0],dateArray[1]);
	    		}	
	    		
	    		
	    		if(current<minimum) {
	    				alert('{$this->invalid_start_error_message}');
	    				obj.value='{$this->startDate}';
	    				//obj.focus();	
	    				
	    		}
	    		if(current>maximum) {
	    				alert('{$this->invalid_end_error_message}');
	    				obj.value='{$this->endDate}';
	    				//obj.focus();
	    				
	    		} 
	    		dateArray= obj.value.split('/');
	    		if(".$this->date_format."==2)
	    		{
	    			theDate=dateArray[2]+'-'+dateArray[1]+'-'+dateArray[0];
	    		} else {
	    			theDate=dateArray[2]+'-'+dateArray[0]+'-'+dateArray[1];	 
	    		}    				
	    		document.getElementById('{$this->sqlID}').value=theDate; 
	    					    		
	    		return true;		
	    	}	";	
	    $calendario .="</script>
	    <div id='calendario".$num."_div' onmouseover='document.onmousedown = null;' onmouseout='document.onmousedown = CalendarPopup_Up_LostFocus;' style='visibility:hidden;z-index:5000;position:absolute;'></div>
	    <div id='calendario".$num."_monthYear' onmouseover='document.onmousedown = null;' onmouseout='document.onmousedown = CalendarPopup_Up_LostFocus;' style='visibility:hidden;z-index:5001;position:absolute;'></div>
	    <!-- CALENDAR END -->
	    ";
		
	    echo $calendario;
	    return ;
	} // End function CreateCalendar
	
	/******************************************
	This function takes care of setting up properly a SQL
	formatted date into the format used by the class.
	Addictionally the magic value 'today' is changed into the
	current date.
	
	The rest of the class works in %m/%d/%Y so let's conform...
	*******************************************/
	function setDate($theDate)
	{
		
		if (strlen($theDate)==0)
			return "";
			
		if ($theDate == "today")
		{
			switch ($this->date_format)
			{
				case 1:			// mm/dd/aaaa
				 $theDate= strftime("%m/%d/%Y",time());
				break;
				case 2:			// dd/mm/aaaa
				 $theDate = strftime("%d/%m/%Y",time());	
				break;
				
			}
		}		
		else
		{
			
			list ($year, $month, $day) = split('[/.-]', $theDate);
			//$theDate= "$month/$day/$year";
			
			switch ($this->date_format)
			{
				case 1:			// mm/dd/aaaa
				 $theDate= "$month/$day/$year";
				break;
				case 2:			// dd/mm/aaaa
				 $theDate = "$day/$month/$year";
				break;
				
			}
			
		}
		return $theDate;
	}
	
	
	function sqlCurrent()
	{
		if (strlen($this->curVal)) 
		{
			switch ($this->date_format)
			{
				case 1:
					list ($mese, $giorno, $anno) =split("/", $this->curVal);
					break;
				case 2:
					list ($giorno, $mese, $anno) =split("/", $this->curVal);
					break;
			}
			return "$anno-$mese-$giorno";
		}
		else
			return "";
	}
	
	/*
	 * Esegue la validazione del campo se serve
	 * 
	 * Il metodo � richiesto per la funzione Validate della classe madre
	 * 
	 * Alex 1-2-2006
	 * 
	 * 30-4-2006 Implemented the validateInput method by Alex
	 */
	function ValidateInput(&$form)
	{
		$date=$form->GetInputValue($this->sqlID);
		
		// if optional and not set return no error
		if($this->optional && (strlen($date)==0))
			return "";
			
		// if startDate is defined then check against it
		list ($year,$month,$day)=explode("-",$date);
		list($startYear,$startMonth,$startDay)=explode("-",$this->startDate);
		
		$current = mktime(0,0,0,$day,$month,$day);
		$start = mktime(0,0,0,$startDay,$startMonth,$startYear);
		
		if(($start>0) && ($current < $start))
			return $this->invalid_start_error_message ;
		// if endDate is defined the check agains it	
		list($endYear,$endMonth,$endDay)=explode("-",$this->endDate);
		$end = mktime(0,0,0,$endDay, $endMonth, $endYear);
		
		if (($end >0) && ($current > $end))
			return $this->invalid_end_error_message ;
		
		return "";		// no error detected
		
	}
	/*
	 * Output fo the script only once even if more instances exist
	 */
	private function outputJS()
	{
		if( $this->JS_DONE==false)
		{
		
			$this->outJS = true;	
?>
		<script language="Javascript">
		<!--

/*
	Note by alex
	riga 287 cambiato l'allineamento da right a center
	riga 731 aggiunta la chiamata a setupSQL
	Aggiunta la funzione setupSQL
	20-11-2005
	
	30-04-2006 Added the sqlObj parameter to the functions and embedded
	the javascript into the plugin class itself
*/
var CalendarPopup_curCalendar = '';
var CalendarPopup_curCalendarID = '';
var CalendarPopup_curMonthYear = '';
var CalendarPopup_selMonth = '';
var CalendarPopup_selYear = '';
if (navigator.appName == 'Netscape') { document.captureEvents(Event.CLICK); }

function scrivi_data_odierna(tipo){
//con tipo=2 scrive la data in formato gg/mm/yyyy 
//con tipo=1 scrive in formato mm/dd/yyyy 
	var oggi = new Date(); 
	var data = ""; 
	if (tipo==2) 
    {
			data+=oggi.getDate()<10?"0"+oggi.getDate()+" ":oggi.getDate()+"/"; 
			data+=(oggi.getMonth()+1)+"/"; 
			data+=oggi.getFullYear(); 
		} else {
			data+=(oggi.getMonth()+1)+"/"; 
			data+=oggi.getDate()<10?"0"+oggi.getDate()+" ":oggi.getDate()+"/"; 
			data+=oggi.getFullYear(); 
		}
	return data;
}

function CalendarPopup_Up_LostFocus(e) { CalendarPopup_Up_HideNonCurrentCalendar('', ''); }

function CalendarPopup_Up_Holiday(month, day, year, span) {
	this.Month = month;
	this.Day = day;
	this.Year = year;
	this.Span = span;
}

function CalendarPopup_Up_IsHoliday(month, day, year, dateArray) {
	var returnVal = false;
	
	if(dateArray == null) {
		returnVal = false;
	} else {
		for(var i=0; i<dateArray.length; i++) 
          {
			if(dateArray[i].Month == (month + 1) && dateArray[i].Day == day && (dateArray[i].Year == year || dateArray[i].Span)) {
				returnVal = true;
				i = dateArray.length;
			} else {
				returnVal = false;
			}
		}
	}
	
	return returnVal;
}

function CalendarPopup_Up_GiornoLinkabile(month, day, year,valori) {
//stabilisce se una data � riferita ad un giorno della settimana che l'utente vuole sia linkabile
//restituisce vero o falso
	var returnVal = false;
	var giorno=new Date(year,month,day);
	result=giorno.getDay();

     for(var i=0; i<valori.length; i++) 
     {
          if(result==valori[i]) 
          {
          	returnVal = true;
          } 
     }
	return returnVal;
}


function CalendarPopup_Up_GiornoLinkabile2(month, day, year,valori) {
//stabilisce se una data � riferita ad un giorno della settimana che l'utente vuole sia linkabile
//restituisce vero o falso
     month_lang=new Array('january','february','march','april','may','june','july','august','september','october','november','december');
	var returnVal = false;
	//alert (month_lang[month-1]);
	stringa=month_lang[month-1]+ " "+ day+", "+ year;
	var giorno=new Date(stringa);
	result=giorno.getDay();
	//alert(stringa+"--->"+giorno.getDay());
	for(var i=0; i<valori.length; i++) 
     {
          if(result==valori[i]) 
          {
          	returnVal = true;
          } 
     }
     //alert(stringa+"--->"+returnVal);
	return returnVal;
	//return giorno.getDay();
}

function CalendarPopup_Up_findPosX(obj)
{
	var curleft = 0;
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curleft += obj.offsetLeft;
			obj = obj.offsetParent;
		}
	}
	else if (obj.x) {
		curleft += obj.x;
	}
	return curleft;
}

function CalendarPopup_Up_findPosY(obj)
{
	var curtop = 0;
	if (obj.offsetParent)
	{
		while (obj.offsetParent)
		{
			curtop += obj.offsetTop;
			obj = obj.offsetParent;
		}
	}
	else if (obj.y)
		curtop += obj.y;
	return curtop;
}

function CalendarPopup_Up_DisplayCalendar(giorni,calIdFlag, tbName, lblName, lblTemp, divName, myName, funcName, myFuncName, wdStyle, weStyle, omStyle, sdStyle, mhStyle, dhStyle, cdStyle, tdStyle, gttStyle, holStyle, formatNum, monthnames, daynames, fdweek, sunNum, satNum, enableHide, includeYears, lBound, uBound, btnName, locQuad, pad, postbackFunc, offsetX, offsetY, showClear, clearText, showGoToToday, goToTodayText, arrowUrl, customFunc, calWidth, visibleKey, nullText, dateArray, nextMonthImgUrl, prevMonthImgUrl, nextYearImgUrl, prevYearImgUrl, sqlObj) {
	var div, tb;
	CalendarPopup_curCalendarID = calIdFlag;
	div = document.getElementById(divName);
	tb = document.getElementById(tbName);
	if(div.style.visibility != 'hidden') {
		div.style.visibility = 'hidden';
		if(enableHide)
			CalendarPopup_Up_ShowHideDDL('visible');
	} else {
		var todayDate = CalendarPopup_Up_GetDate(tbName, formatNum);
		eval('var stringDate = ' + visibleKey + ';');
		CalendarPopup_Up_HideNonCurrentCalendar(divName, myName)
		if(enableHide)
			CalendarPopup_Up_ShowHideDDL('hidden');
		div.style.position = 'absolute';
		var obj;
		if(lblTemp != '')
			obj = document.getElementById(lblTemp);
		else if(lblName != '')
			obj = document.getElementById(lblName);
		else
			obj = tb;
		var y = CalendarPopup_Up_findPosY(obj);
		var x = CalendarPopup_Up_findPosX(obj);
		switch(locQuad) {
			case 1:
				y += (obj.offsetHeight + 1);
				break;
			case 2:
				x -= (div.offsetWidth - 2);
				break;
			case 3:
				x += (obj.offsetWidth + 1);
				break;
			case 4:
				y -= (div.offsetHeight - 1);
				break;
			default:
				y = CalendarPopup_Up_findPosY(document.getElementById(btnName));
				x = CalendarPopup_Up_findPosX(document.getElementById(btnName)) - 3;
				break;
		}
		div.style.top = y + offsetY + 'px';
		div.style.left = x + offsetX + 'px';
		CalendarPopup_Up_DisplayCalendarByDate(giorni,tbName, lblName, divName, myName, funcName, myFuncName, stringDate, wdStyle, weStyle, omStyle, sdStyle, mhStyle, dhStyle, cdStyle, tdStyle, gttStyle, holStyle, formatNum, monthnames, daynames, fdweek, sunNum, satNum, enableHide, includeYears, lBound, uBound, pad, postbackFunc, showClear, clearText, showGoToToday, goToTodayText, arrowUrl, customFunc, calWidth, visibleKey, nullText, dateArray, nextMonthImgUrl, prevMonthImgUrl, nextYearImgUrl, prevYearImgUrl, sqlObj);
		div.style.visibility = 'visible';
	}
}

function CalendarPopup_Up_ChangeMonth(selMonth, lbDate, ubDate) {
	if(document.getElementById('CalendarPopup_monthname' + selMonth).style.color == 'black') {
		for(var i=0; i<12; i++) {
			if(i != selMonth)
				document.getElementById('CalendarPopup_monthname' + i).style.background='white';
			else
				document.getElementById('CalendarPopup_monthname' + i).style.background='lightgrey';
		}
		CalendarPopup_selMonth = selMonth++;
	}
}

function CalendarPopup_Up_ChangeYear(selYear, yearNum, lbDate, ubDate) {
	var lowerDate = new Date(lbDate);
	var upperDate = new Date(ubDate);
	lowerDate = new Date((lowerDate.getMonth() + 1) + '/1/' + lowerDate.getFullYear());
	for(var i=0; i<10; i++) {
		if(i != selYear)
			document.getElementById('CalendarPopup_yearname' + i).style.background='white';
		else
			document.getElementById('CalendarPopup_yearname' + i).style.background='lightgrey';
	}
	for(var i=0; i<12; i++) {
		var curDate = new Date((i + 1) + '/1/' + yearNum);
		if(curDate < lowerDate || curDate > upperDate)
			document.getElementById('CalendarPopup_monthname' + i).style.color = 'gray';
		else
			document.getElementById('CalendarPopup_monthname' + i).style.color = 'black';
		document.getElementById('CalendarPopup_monthname' + i).style.background = 'white';
	}
	var curDate = new Date((CalendarPopup_selMonth + 1) + '/1/' + yearNum);
	if(curDate <= lowerDate)
		CalendarPopup_selMonth = lowerDate.getMonth();
	else if(curDate >= upperDate)
		CalendarPopup_selMonth = upperDate.getMonth();
	document.getElementById('CalendarPopup_monthname' + CalendarPopup_selMonth).style.background = 'lightgrey';
	CalendarPopup_selYear = yearNum;
}

function CalendarPopup_Up_ChangeMonthYear(divName, funcName, isCancel) {
	if(!isCancel) {
		eval(funcName + "('" + (CalendarPopup_selMonth + 1) + "/1/" + CalendarPopup_selYear + "');");
	}
	document.getElementById(divName).style.visibility = 'hidden';
	document.getElementById(divName).innerHTML = '';
	document.onmousedown = CalendarPopup_Up_LostFocus;
}

function CalendarPopup_Up_DisplayMonthYear(calDivName, myDivName, funcName, myFuncName, monthnames, theDate, applyText, cancelText, lbDate, ubDate) {
	var calDIV = document.getElementById(calDivName);
	var myDIV = document.getElementById(myDivName);
	var curDate = new Date(theDate);
	var lowerDate;
	var upperDate = new Date(ubDate);
	
	if (lbDate=='')
		lowerDate = new Date('1/1/1904');
	else
		lowerDate = new Date(lbDate);
	
	lowerDate = new Date((lowerDate.getMonth() + 1) + '/1/' + lowerDate.getFullYear());	
	
		CalendarPopup_selMonth = curDate.getMonth();
	if(curDate < lowerDate)
		CalendarPopup_selMonth = lowerDate.getMonth();
	else if(curDate > upperDate)
		CalendarPopup_selMonth = upperDate.getMonth();
	CalendarPopup_selYear = curDate.getFullYear();
	
	outputString = '<table style=\"border: black 1px solid;background: white;\" border=0 cellspacing=0 cellpadding=0>';
	outputString = outputString + '<tr><td width=50% valign=top><table border=0 cellspacing=0 cellpadding=2>';
	//stampa i mesi
     for(var i=0; i<12; i++) {
		if(i % 2 == 0)
			outputString = outputString + '<tr>';
		var tempDate = new Date((i + 1) + '/1/' + CalendarPopup_selYear);
		if(tempDate >= lowerDate  && tempDate <= upperDate) {
			if(i == CalendarPopup_selMonth)
				outputString = outputString + "<td id=\"CalendarPopup_monthname" + i + "\" onclick=\"CalendarPopup_Up_ChangeMonth(" + i + ", '" + lbDate + "', '" + ubDate + "')\" align=left nowrap style=\"font-family:verdana; font-size:xx-small; color: black;background:lightgrey; cursor:hand;\">" + monthnames[i] + "</td>";
			else
				outputString = outputString + "<td id=\"CalendarPopup_monthname" + i + "\" onclick=\"CalendarPopup_Up_ChangeMonth(" + i + ", '" + lbDate + "', '" + ubDate + "')\" align=left nowrap style=\"font-family:verdana; font-size:xx-small; color: black; cursor:hand;\">" + monthnames[i] + "</td>";
		} else {
			outputString = outputString + "<td id=\"CalendarPopup_monthname" + i + "\" onclick=\"CalendarPopup_Up_ChangeMonth(" + i + ", '" + i + lbDate + "', '" + ubDate + "')\" align=left nowrap style=\"font-family:verdana; font-size:xx-small; color: gray; cursor:hand;\">" + monthnames[i] + "</td>";
		}
		if(i % 2 != 0)
			outputString = outputString + '</tr>';
	}
	outputString = outputString + '</table></td><td width=50% valign=top><table border=0 cellspacing=0 cellpadding=2 width=100%>';
	var j = 0;
	for(var i=(curDate.getFullYear() - 5); i<(curDate.getFullYear() + 5); i++) {
		if(j % 2 == 0)
			outputString = outputString + '<tr>';
		if(i >= lowerDate.getFullYear() && i <= upperDate.getFullYear()) {
			if(i == curDate.getFullYear())
				outputString = outputString + "<td id=\"CalendarPopup_yearname" + j + "\" onclick=\"CalendarPopup_Up_ChangeYear(" + j + ", " + i + ", '" + lbDate + "', '" + ubDate + "')\" align=left nowrap style=\"font-family:verdana; font-size:xx-small;color: black;background: lightgrey; cursor:hand;\">" + i + "</td>";
			else
				outputString = outputString + "<td id=\"CalendarPopup_yearname" + j + "\" onclick=\"CalendarPopup_Up_ChangeYear(" + j + ", " + i + ", '" + lbDate + "', '" + ubDate + "')\" align=left nowrap style=\"font-family:verdana; font-size:xx-small;color: black; cursor:hand;\">" + i + "</td>";
		} else {
			outputString = outputString + "<td id=\"CalendarPopup_yearname" + j + "\" align=left nowrap style=\"font-family:verdana; font-size:xx-small;color: gray; cursor:hand;\">" + i + "</td>";
		}
		if(j % 2 != 0)
			outputString = outputString + '</tr>';
		j++;
	}
	outputString = outputString + "<tr><td align=left><a style=\"font-family:verdana; font-size:xx-small; color: black;\" href=\"javascript:" + myFuncName + "((CalendarPopup_selMonth + 1) + '/" + curDate.getDate() + "/" + (curDate.getFullYear() - 10) + "')\">&lt;&lt;</a></td>";
	outputString = outputString + "<td align=right><a style=\"font-family:verdana; font-size:xx-small; color: black;\" href=\"javascript:" + myFuncName + "((CalendarPopup_selMonth + 1) + '/" + curDate.getDate() + "/" + (curDate.getFullYear() + 10) + "')\">&gt;&gt;</a></td></tr>";
	outputString = outputString + '</table></td></tr>';
	// cambiato right con center Alex
	outputString = outputString + "<tr><td colspan=2 align=center nowrap><input onclick=\"CalendarPopup_Up_ChangeMonthYear('" + myDivName + "', '" + funcName + "', false);\" type=button value=\"" + applyText + "\" style=\"font-family:verdana; font-size:xx-small\"><input onclick=\"CalendarPopup_Up_ChangeMonthYear('" + myDivName + "', '" + funcName + "', true);\" type=button value=\"" + cancelText + "\" style=\"font-family:verdana; font-size:xx-small\"></td></tr>";
	
	myDIV.style.position = 'absolute';
	myDIV.style.top = parseInt(calDIV.style.top.replace('px', '')) + 2;
	myDIV.style.left = parseInt(calDIV.style.left.replace('px', '')) + 2;
	myDIV.innerHTML = outputString;
	myDIV.style.visibility = 'visible';
}

function CalendarPopup_Up_HideNonCurrentCalendar(divName, myName) {
	if(CalendarPopup_curMonthYear != '') {
		document.getElementById(CalendarPopup_curMonthYear).style.visibility = 'hidden';
		document.getElementById(CalendarPopup_curMonthYear).innerHTML = '';
	}
	if(CalendarPopup_curCalendar != '') {
		document.getElementById(CalendarPopup_curCalendar).style.visibility = 'hidden';
		document.getElementById(CalendarPopup_curCalendar).innerHTML = '';
		if(eval(CalendarPopup_curCalendarID) == true)
			CalendarPopup_Up_ShowHideDDL('visible');
	}
	if(divName != '')
		CalendarPopup_curCalendar = divName;
	if(myName != '')
		CalendarPopup_curMonthYear = myName;
}

function CalendarPopup_Up_GetDate(tbName, formatNum) {
	var todayDate;
	if(document.getElementById(tbName).value != '') {
		var theDate;
		var theDateArr = document.getElementById(tbName).value.split("/");
		if(theDateArr.length != 3) {
			theDateArr = document.getElementById(tbName).value.split(".");
			if(theDateArr.length != 3)
				theDateArr = document.getElementById(tbName).value.split("-");
		}
		if(theDateArr.length == 3) {
			switch(formatNum) {
				case 1: // In: MM/DD/YYYY Out: MM/DD/YYYY
					theDate = theDateArr[0].concat("/").concat(theDateArr[1]).concat("/").concat(theDateArr[2]);
					break;
				case 2: // In: DD/MM/YYYY Out: MM/DD/YYYY
					theDate = theDateArr[1].concat("/").concat(theDateArr[0]).concat("/").concat(theDateArr[2]);
					break;
				case 3: // In: YYYY/MM/DD Out: MM/DD/YYYY
					theDate = theDateArr[1].concat("/").concat(theDateArr[2]).concat("/").concat(theDateArr[0]);
					break;
				case 4: // In MM.DD.YYYY Out: MM.DD.YYYY
					theDate = theDateArr[0].concat("/").concat(theDateArr[1]).concat("/").concat(theDateArr[2]);
					break;
				case 5: // In DD.MM.YYYY Out: MM.DD.YYYY
					theDate = theDateArr[1].concat("/").concat(theDateArr[0]).concat("/").concat(theDateArr[2]);
					break;
				case 6: // In YYYY.MM.DD Out: MM.DD.YYYY
					theDate = theDateArr[1].concat("/").concat(theDateArr[2]).concat("/").concat(theDateArr[0]);
					break;
				case 7: // In MM-DD-YYYY Out: MM-DD-YYYY
					theDate = theDateArr[0].concat("/").concat(theDateArr[1]).concat("/").concat(theDateArr[2]);
					break;
				case 8: // In DD-MM-YYYY Out: MM-DD-YYYY
					theDate = theDateArr[1].concat("/").concat(theDateArr[0]).concat("/").concat(theDateArr[2]);
					break;
				case 9: // In YYYY-MM-DD Out: MM-DD-YYYY
					theDate = theDateArr[1].concat("/").concat(theDateArr[2]).concat("/").concat(theDateArr[0]);
					break;
			}
			todayDate = new Date(theDate);
			if(todayDate == NaN)
				todayDate = new Date();
		} else
			todayDate = new Date();
	} else
		todayDate = new Date();
	return todayDate;
}

function CalendarPopup_Up_ShowHideDDL(visibility) {
	for(j=0;j<document.forms.length; j++) {
		for(i=0;i<document.forms[j].elements.length;i++) {
			if(document.forms[j].elements[i].type != null) {
				if(document.forms[j].elements[i].type.indexOf('select') == 0)
					document.forms[j].elements[i].style.visibility = visibility;
			}
		}
	}
}

function CalendarPopup_Up_DisplayCalendarByDate(giorni,tbName, lblName, divName, myName, funcName, myFuncName, stringDate, wdStyle, weStyle, omStyle, sdStyle, mhStyle, dhStyle, cdStyle, tdStyle, gttStyle, holStyle, formatNum, monthnames, daynames, fdweek, sunNum, satNum, enableHide, includeYears, lBound, uBound, pad, postbackFunc, showClear, clearText, showGoToToday, goToTodayText, arrowUrl, customFunc, calWidth, visibleKey, nullText, dateArray, nextMonthImgUrl, prevMonthImgUrl, nextYearImgUrl, prevYearImgUrl, sqlObj)
{
     //MODIFICATO PESANTEMENTE
     // this function of core is edit for link not all days of weeks
     var dateToday = new Date();
	var lowerDate = new Date(lBound);
	var upperDate = new Date(uBound);
	var todayDate = new Date(stringDate);
	var curDate = new Date(CalendarPopup_Up_GetDate(tbName, formatNum));
	var curMonth = curDate.getMonth();
	var curYear = curDate.getFullYear();
	var monthdays = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
	thisday=todayDate.getDay();
	thismonth=todayDate.getMonth();
	thisdate=todayDate.getDate();
	thisyear=todayDate.getFullYear();
	if (((thisyear % 4 == 0) && !(thisyear % 100 == 0)) ||(thisyear % 400 == 0))
		monthdays[1]++;
	var outputString = '';
	startspaces=thisdate;
	var prevMonth = thismonth;
	var prevDay = thisdate;
	var prevYear = thisyear;
	var thisPreviousYear = thisyear - 1;
	var thisNextYear = thisyear + 1;
	if(prevMonth < 1) {
		prevMonth = 12;
		prevYear = prevYear - 1;
	}
	if(thisdate > monthdays[prevMonth - 1])
		prevDay = monthdays[prevMonth - 1];
	var nextMonth = thismonth + 2;
	var nextDay = thisdate;
	var nextYear = thisyear;
	if(nextMonth > 12) {
		nextMonth = 1;
		nextYear = nextYear + 1;
	}
	if(thisdate > monthdays[nextMonth - 1])
		nextDay = monthdays[nextMonth - 1];
	while (startspaces > 7)
		startspaces-=7;
	startspaces = thisday - startspaces + 1;
	startspaces = startspaces - fdweek;
	if (startspaces < 0)
		startspaces+=7;
	outputString = outputString + '<table';
	if(calWidth > 0)
		outputString = outputString + ' width=\"' + calWidth + 'px\"';
	outputString = outputString + ' style=\"border: black 1px solid;\" border=0 cellspacing=0px cellpadding=2px>';
	if (includeYears == false) {
		if(prevMonthImgUrl == '')
			outputString = outputString + "<tr " + mhStyle + "><td align=center><a " + mhStyle + " href=\"javascript:" + funcName + "('" + prevMonth + "/" + prevDay + "/" + prevYear + "')\">&lt;</a></td>";
		else
			outputString = outputString + "<tr " + mhStyle + "><td align=center><a " + mhStyle + " href=\"javascript:" + funcName + "('" + prevMonth + "/" + prevDay + "/" + prevYear + "')\"><img src=\"" + prevMonthImgUrl + "\" border=0></a></td>";
	} else {
		if(prevMonthImgUrl == '')
			outputString = outputString + "<tr " + mhStyle + "><td align=center><a " + mhStyle + " href=\"javascript:" + funcName + "('" + prevMonth + "/" + prevDay+ "/" + prevYear + "')\">&lt;</a><br>";
		else
			outputString = outputString + "<tr " + mhStyle + "><td align=center><a " + mhStyle + " href=\"javascript:" + funcName + "('" + prevMonth + "/" + prevDay+ "/" + prevYear + "')\"><img src=\"" + prevMonthImgUrl + "\" border=0></a><br>";
		
		if(prevYearImgUrl == '')
			outputString = outputString + "<a " + mhStyle + " href=\"javascript:" + funcName + "('" + (thismonth + 1) + "/" + thisdate + "/" + thisPreviousYear + "')\">&lt;&lt;</a></td>";
		else
			outputString = outputString + "<a " + mhStyle + " href=\"javascript:" + funcName + "('" + (thismonth + 1) + "/" + thisdate + "/" + thisPreviousYear + "')\"><img src=\"" + prevYearImgUrl + "\" border=0></a></td>";
	}
	outputString = outputString + '<td colspan=5 nowrap align=center ' +mhStyle + "><a " + mhStyle + " href=\"javascript:" + myFuncName + "('" + (thismonth + 1) + "/1/" + thisyear + "')\">" + monthnames[thismonth] + ' ' + thisyear;
	if(arrowUrl != "")
		outputString = outputString + ' <img src=\"' + arrowUrl + '\" border=0>';
	outputString = outputString + '</a></td>';
	if (includeYears == false) {
		if(nextMonthImgUrl == '')
			outputString = outputString + "<td align=center><a " + mhStyle + " href=\"javascript:" + funcName + "('" + nextMonth + "/" + nextDay + "/" + nextYear + "')\">&gt;</a></td></tr>";
		else
			outputString = outputString + "<td align=center><a " + mhStyle + " href=\"javascript:" + funcName + "('" + nextMonth + "/" + nextDay + "/" + nextYear + "')\"><img src=\"" + nextMonthImgUrl + "\" border=0></a></td></tr>";
	} else {
		if(nextMonthImgUrl == '')
			outputString = outputString + "<td align=center><a " + mhStyle + " href=\"javascript:" + funcName + "('" + nextMonth + "/" + nextDay+ "/" + nextYear + "')\">&gt;</a><br>";
		else
			outputString = outputString + "<td align=center><a " + mhStyle + " href=\"javascript:" + funcName + "('" + nextMonth + "/" + nextDay+ "/" + nextYear + "')\"><img src=\"" + nextMonthImgUrl + "\" border=0></a><br>";
		
		if(nextYearImgUrl == '')
			outputString = outputString + "<a " + mhStyle + " href=\"javascript:" + funcName + "('" + (thismonth + 1) + "/" + thisdate + "/" + thisNextYear + "')\">&gt;&gt;</a></td></tr>";
		else
			outputString = outputString + "<a " + mhStyle + " href=\"javascript:" + funcName + "('" + (thismonth + 1) + "/" + thisdate + "/" + thisNextYear + "')\"><img src=\"" + nextYearImgUrl + "\" border=0></a></td></tr>";
	}
	//stampa i nomi dei giorni
	outputString = outputString + '<tr>';
	outputString = outputString + '<td ' + dhStyle + ' align=center>' + daynames[0] + '</td>';
	outputString = outputString + '<td ' + dhStyle + ' align=center>' + daynames[1] + '</td>';
	outputString = outputString + '<td ' + dhStyle + ' align=center>' + daynames[2] + '</td>';
	outputString = outputString + '<td ' + dhStyle + ' align=center>' + daynames[3] + '</td>';
	outputString = outputString + '<td ' + dhStyle + ' align=center>' + daynames[4] + '</td>';
	outputString = outputString + '<td ' + dhStyle + ' align=center>' + daynames[5] + '</td>';
	outputString = outputString + '<td ' + dhStyle + ' align=center>' + daynames[6] + '</td>';
	outputString = outputString + '</tr>';
	//stampa i giorni cio� i numeri dei mesi prima e dopo
     for (s=0;s<startspaces;s++) 
     {
		var theDate, month, year;
		if(thismonth == 0) {
			theDate = monthdays[11] - (startspaces - (s + 1));
			month = 12;
			year = thisyear - 1;
		} else {
			theDate = monthdays[thismonth - 1] - (startspaces - (s + 1));
			month = thismonth;
			year = thisyear;
		}
		var theCurDate = new Date(month + "/" + theDate + "/" + year);
		var lowerAmount = (lowerDate - theCurDate);
		var upperAmount = (theCurDate - upperDate);	
		if(s == 0)
			outputString = outputString + '<tr>';
		if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0)){
			//stampa i giorni del mese prima PRIMA DELL'intervallo voluto
               outputString = outputString + "<td align=center " + omStyle + "\">" + theDate + "</td>";
		}else if(s!=sunNum && s!=satNum){
		   //stampa i giorni FERIALI del mese prima ALL'INTERNO dell'intervallo voluto
		   //##################################################################
		    if (CalendarPopup_Up_GiornoLinkabile2(thismonth, theDate, thisyear,giorni)) {
                    outputString = outputString + "<td align=center " + omStyle + "><a " + omStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + month + "/" + theDate + "/" + year + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + theDate + "</a></td>";
               } else {
                     outputString = outputString + "<td align=center " + omStyle + ">" + theDate + "</td>";
               }
               //outputString = outputString + "<td align=center " + omStyle + "><a " + omStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + month + "/" + theDate + "/" + year + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + theDate + "</a></td>";
			//outputString = outputString + "<td align=center " + omStyle + ">" + theDate + "</td>";
			//##################################################################
		}else{
		   //stampa i giorni FESTIVI del mese prima ALL'INTERNO l'intervallo voluto
		   	if (CalendarPopup_Up_GiornoLinkabile2(thismonth, theDate, thisyear,giorni)) {
                    outputString = outputString + "<td align=center " + omStyle + "><a " + omStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + month + "/" + theDate + "/" + year + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey + "' ,'"+ sqlObj + "')\">" + theDate + "</a></td>";
               } else {
                     outputString = outputString + "<td align=center " + omStyle + ">" + theDate + "</td>";
               }
             //outputString = outputString + "<td align=center " + omStyle + "><a " + omStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + month + "/" + theDate + "/" + year + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + theDate + "</a></td>";
		}
	}
	count=1;
	//stampa i giorni della settimana nel mese
	while (count <= monthdays[thismonth]) {
		for (b = startspaces;b<7;b++) {
			if(b == 0)
				outputString = outputString + '<tr>';
			if((thismonth == dateToday.getMonth() && count == dateToday.getDate() && thisyear == dateToday.getFullYear()) || (count==curDate.getDate() && thismonth == curMonth && thisyear == curYear && document.getElementById(tbName).value != '')) {
				if (count==curDate.getDate() && thismonth == curMonth && thisyear == curYear && document.getElementById(tbName).value != '')
					//stampa data selezionata
                         outputString = outputString + '<td align=center ' + sdStyle + '>';
				else if(CalendarPopup_Up_IsHoliday(thismonth, count, thisyear, dateArray))
					outputString = outputString + '<td align=center ' + holStyle + '>';
				else if(thismonth == dateToday.getMonth() && count == dateToday.getDate() && thisyear == dateToday.getFullYear())
					outputString = outputString + '<td align=center ' + tdStyle + '>';
			} else {
				if (count <= monthdays[thismonth]) {
					if(CalendarPopup_Up_IsHoliday(thismonth, count, thisyear, dateArray)) {
						outputString = outputString + '<td align=center ' + holStyle + '>';
					} else {
						if(b!=sunNum && b!=satNum) {
						    //giorni non del week end
							outputString = outputString + '<td align=center ' + wdStyle + '>';
						} else {
					     	//giorni  del week end
							outputString = outputString + '<td align=center ' + weStyle + '>';
						}
					}
				} else {
				      //giorni del week end DENTRO il mese dopo NELL'INTERVALLO VOLUTO
					outputString = outputString + '<td align=center ' + omStyle + '>';
				}
			}
			if (count <= monthdays[thismonth]) {
				var theCurDate = new Date((thismonth + 1) + "/" + count + "/" + thisyear);
				var lowerAmount = (lowerDate - theCurDate);
				var upperAmount = (theCurDate - upperDate);	
				
				if((thismonth == dateToday.getMonth() && count == dateToday.getDate() && thisyear == dateToday.getFullYear()) || (count==curDate.getDate() && thismonth == curMonth && thisyear == curYear && document.getElementById(tbName).value != '')) {
					if (count==curDate.getDate() && thismonth == curMonth && thisyear == curYear && document.getElementById(tbName).value != '') {							
						if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0))
							outputString = outputString + "<span " + sdStyle + ">" + count + "</span>"; 
						else
							//CREA LINK PER LA DATA SELEZIONATA
							//##################################################################
                                   //a=;
                                   if (CalendarPopup_Up_GiornoLinkabile(thismonth, count, thisyear,giorni)) {
                                        outputString = outputString + "<a " + sdStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
                                   } else {
                                         outputString = outputString +  count ;
                                   }
                                   //outputString = outputString + "X<a " + sdStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
                                   //##################################################################
					} else if(CalendarPopup_Up_IsHoliday(thismonth, count, thisyear, dateArray)) {
						if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0))
							outputString = outputString + "<span " + holStyle + ">" + count + "</span>"; 
						else
							outputString = outputString + "<a " + holStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
					} else if(thismonth == dateToday.getMonth() && count == dateToday.getDate() && thisyear == dateToday.getFullYear()) {
						if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0))
							outputString = outputString + "<span " + tdStyle + ">" + count + "</span>"; 
						else
						     //CREA LINK PER LA DATA ODIERNA SE NON GIA' ATTIVATA
						     //##################################################################
							if (CalendarPopup_Up_GiornoLinkabile(thismonth, count, thisyear,giorni)) {
						         outputString = outputString + "<a " + tdStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
                                   }else{
                                         outputString = outputString + count ;
                                   }
                                   //outputString = outputString + "X<a " + tdStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
							//##################################################################
					}
				} else if(CalendarPopup_Up_IsHoliday(thismonth, count, thisyear, dateArray)) {
					if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0))
						outputString = outputString + "<span " + holStyle + ">" + count + "</span>"; 
					else
						outputString = outputString + "<a " + holStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
				} else if(b!=sunNum && b!=satNum && count != thisdate) {
					if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0))
						outputString = outputString + "<span " + wdStyle + ">" + count + "</span>"; 
					else
					     //LINK GIORNI FERIALI SETTIMANA DEL MESE IN CORSO
					     //##################################################################
						if (CalendarPopup_Up_GiornoLinkabile(thismonth, count, thisyear,giorni)) {
						    outputString = outputString + "<a " + wdStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
                              }else{
                                   outputString = outputString + count ;
                              }
                              //outputString = outputString + "X<a " + wdStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
						//##################################################################
				} else if(b!=sunNum && b!=satNum) {
					if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0))
						outputString = outputString + "<span " + wdStyle + ">" + count + "</span>"; 
					else
						if (CalendarPopup_Up_GiornoLinkabile(thismonth, count, thisyear,giorni)) {
					          outputString = outputString + "<a " + wdStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
                              }else{
                                    outputString = outputString + count ;
                              }
                             // outputString = outputString + "�<a " + wdStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
				} else {
					if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0))
						outputString = outputString + "<span " + weStyle + ">" + count + "</span>"; 
					else
					     //LINK GIORNI WEEK END SETTIMANA DEL MESE IN CORSO
					     //##################################################################
						if (CalendarPopup_Up_GiornoLinkabile(thismonth, count, thisyear,giorni)) {
					         outputString = outputString + "<a " + weStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + count + "</a>";
                              }else{
                                    outputString = outputString + count ;
                              }
                              //outputString = outputString + "X<a " + weStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + (thismonth + 1) + "/" + count + "/" + thisyear + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj + "')\">" + count + "</a>";
						//##################################################################
				}
			} else {
				var month, year;
				if(thismonth == 11) {
					month = 1;
					year = thisyear + 1;
				} else {
					month = thismonth + 2;
					year = thisyear;
				}
				var theCurDate = new Date(month + "/" + (count - monthdays[thismonth]) + "/" + year);
				var lowerAmount = (lowerDate - theCurDate);
				var upperAmount = (theCurDate - upperDate);	
				if((lowerAmount > 0 && upperAmount < 0) || (upperAmount > 0 && lowerAmount < 0))
					outputString = outputString + "<span " + omStyle + ">" + (count - monthdays[thismonth]) + "</span>";
				else
				      //LINK DEI GIORNI DEL MESE DOPO
				      //##################################################################
					if (CalendarPopup_Up_GiornoLinkabile(thismonth, count, thisyear,giorni)) {
				         outputString = outputString + "<a " +omStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + month + "/" + (count - monthdays[thismonth]) + "/" + year + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey +  "' ,'"+ sqlObj +"')\">" + (count - monthdays[thismonth]) + "</a>";
                         }else{
                               outputString = outputString + count ;
                         }
                         //outputString = outputString + "X<a " +omStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + month + "/" + (count - monthdays[thismonth]) + "/" + year + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey + "' ,'"+ sqlObj + "')\">" + (count - monthdays[thismonth]) + "</a>";
					//##################################################################
			}
			outputString = outputString + '</td>';
			count++;
		}
		outputString = outputString + '</tr>';
		startspaces=0;
	}
	if(showGoToToday) {
		var shortDate = (dateToday.getMonth() + 1) + "/" + dateToday.getDate() + "/" + dateToday.getFullYear();
		outputString = outputString + "<tr><td " + gttStyle + " colspan=\"7\" align=\"center\">" + goToTodayText + " <a " + gttStyle + " href=\"javascript:CalendarPopup_Up_SelectDate('" + tbName + "','" + lblName + "','" + divName + "','" + myName + "','" + shortDate + "', " + formatNum + ", " + enableHide + ", " + pad + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey + "' ,'"+ sqlObj +"' )\">" + CalendarPopup_Up_DetermineDate(shortDate, formatNum, pad) + "</a>";
	}
	if(showClear)
		outputString = outputString + "<tr><td " + cdStyle + " colspan=\"7\" align=\"center\"><a " + cdStyle + " href=\"javascript:CalendarPopup_Up_ClearDate('" + tbName + "','" + lblName + "','" + divName + "', '" + myName + "', " + enableHide + ", '" + postbackFunc + "', '" + customFunc + "', '" + visibleKey + "', '" + nullText + "');\">" + clearText + "</a></td></tr>";
	outputString = outputString + '</table>';
	document.getElementById(divName).innerHTML = outputString;
}

function CalendarPopup_Up_DetermineDate(inDate, formatNum, pad) {
	var theDateArr = inDate.split("/");
	if(theDateArr.length != 3) {
		theDateArr = document.getElementById(tbName).value.split(".");
		if(theDateArr.length != 3) {
			theDateArr = document.getElementById(tbName).value.split("-");
		}		
	}	
	if(pad) {
		if(parseInt(theDateArr[0]) < 10 && theDateArr[0].length == 1)
			theDateArr[0] = '0' + theDateArr[0];
		if(parseInt(theDateArr[1]) < 10 && theDateArr[1].length == 1)
			theDateArr[1] = '0' + theDateArr[1];
		if(parseInt(theDateArr[2]) < 10 && theDateArr[2].length == 1)
			theDateArr[2] = '0' + theDateArr[2];
	}
	var theDate;
	switch(formatNum) {
		case 1: // In: MM/DD/YYYY Out: MM/DD/YYYY
			theDate = theDateArr[0].concat("/").concat(theDateArr[1]).concat("/").concat(theDateArr[2]);
			break;
		case 2: // In: MM/DD/YYYY Out: DD/MM/YYYY
			theDate = theDateArr[1].concat("/").concat(theDateArr[0]).concat("/").concat(theDateArr[2]);
			break;
		case 3: // In: MM/DD/YYYY Out: YYYY/MM/DD
			theDate = theDateArr[2].concat("/").concat(theDateArr[0]).concat("/").concat(theDateArr[1]);
			break;
		case 4: // In MM.DD.YYYY Out: MM.DD.YYYY
			theDate = theDateArr[0].concat(".").concat(theDateArr[1]).concat(".").concat(theDateArr[2]);
			break;
		case 5: // In MM.DD.YYYY Out: DD.MM.YYYY
			theDate = theDateArr[1].concat(".").concat(theDateArr[0]).concat(".").concat(theDateArr[2]);
			break;
		case 6: // In MM.DD.YYYY Out: YYYY.MM.DD
			theDate = theDateArr[2].concat(".").concat(theDateArr[0]).concat(".").concat(theDateArr[1]);
			break;
		case 7: // In MM-DD-YYYY Out: MM-DD-YYYY
			theDate = theDateArr[0].concat("-").concat(theDateArr[1]).concat("-").concat(theDateArr[2]);
			break;
			case 8: // In MM-DD-YYYY Out: DD-MM-YYYY
			theDate = theDateArr[1].concat("-").concat(theDateArr[0]).concat("-").concat(theDateArr[2]);
			break;
		case 9: // In MM-DD-YYYY Out: YYYY-MM-DD
			theDate = theDateArr[2].concat("-").concat(theDateArr[0]).concat("-").concat(theDateArr[1]);
			break;
	}
	return theDate;
}

function CalendarPopup_Up_SelectDate(tbName, lblName, divName, myName, theDate, formatNum, enableHide, pad, postbackFunc, customFunc, visibleKey, sqlObj) 
{
	document.getElementById(tbName).value = CalendarPopup_Up_DetermineDate(theDate, formatNum, pad);
	if(lblName != '')
		document.getElementById(lblName).innerHTML = CalendarPopup_Up_DetermineDate(theDate, formatNum, pad);
	document.getElementById(divName).style.visibility = 'hidden';
	document.getElementById(myName).style.visibility = 'hidden';
	if(enableHide)
		CalendarPopup_Up_ShowHideDDL('visible');
	eval(postbackFunc + "();");
	if(customFunc != "")
		eval(customFunc + "('" + theDate + "', '" + tbName + "');");
	eval(visibleKey + ' = \"' + theDate + '\";');
	//alert("tbName = " + tbName + "sqlObj="+sqlObj);
	//sqlField ="_sql__" + tbName;
	// riga aggiunta da alex
	setupSQL(theDate,sqlObj,formatNum);
}

function CalendarPopup_Up_ClearDate(tbName, lblName, divName, myName, enableHide, postbackFunc, customFunc, visibleKey, nullText) {
	var todayDate = new Date();
	document.getElementById(tbName).value = '';
	if(lblName != '')
		document.getElementById(lblName).innerHTML = nullText;
	document.getElementById(divName).style.visibility = 'hidden';
	document.getElementById(myName).style.visibility = 'hidden';
	if(enableHide)
		CalendarPopup_Up_ShowHideDDL('visible');
	eval(postbackFunc + "();");
	if(customFunc != "")
		eval(customFunc + "('', '" + tbName + "');");
	eval(visibleKey + ' = \"' + (todayDate.getMonth() + 1) + '/' + todayDate.getDate() + '/' + todayDate.getFullYear() + '\";');
}

// funzione aggiunta
function setupSQL( theVal, sqlObjID, formatNum)
{
	// theVal = the date field value
	// sqlObjID = ID of sql hidden field
	// theFormat = date format expected

	var theDateArr = theVal.split("/");
	
	var theDate;
	
	theDate = theDateArr[2].concat("-").concat(theDateArr[0]).concat("-").concat(theDateArr[1]);
			
	document.getElementById(sqlObjID).value = theDate;
	
//	alert("SQL is now " + theDate);
}
/*
*	If an illegal seperator was entered in manual mode, let's change
*   it back to a valida one
*/
function cleanSeparator(obj)
{
	// first check if any non allowed char is in the field
	var theVal = obj.value;
	//alert("valore = " + theVal);
	var temp = "";
	var out ="";
	var test = "/1234567890";
	for( var i=0;  i< theVal.length; i++)
	{
		temp = theVal.charAt(i);
		if ( test.indexOf(temp) == -1)
			out+="/";			// if not in range make ia a separator
		else
			out +=temp;
	}
	obj.value=out;
}
// -->
		
		</script>

<?php		
		}
	
	}
 } // End class
?>
