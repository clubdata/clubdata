<?php

	/*************************** 
	
	GET SURE TO ADJUST YOUR PATHS TO THE CLASSES
	
	WARNING:
	
	The Maunuel Lemos Forms Generation and Validation Class MUST be present 
	
	**************/
	
	require_once("forms.php");              // FIX YOUR PATH
	require_once("cal_class.php");		// the date plugin
	
	
	$form=new form_class;
	$form->NAME="example_form";
	$form->METHOD="POST";
	
	
	// generate the input control
	$form->AddInput(array(
		"TYPE"=>"custom",
		"NAME"=>"start",
		"ID"=>"start",
		"CustomClass"=>"form_calendar_class",
		"LANG"=>"en",				// en= english - it=italian
		"STARTDATE"=>"today",
		"ENDDATE"=>"2006-12-31",
		"LABEL"=>"Start date",
		"VALUE"=>"2005-3-12",
		"SELBG"=>"Green",			// today's background color default Green
		"MONTHBG"=>"Blue",			// month's name background color
		"MONTHTX"=>"White",			// month's name text color
		"WEEKBG"=>"Orange",			// week's name background color
		"WEEKTX"=>"Green",			// week's name text color
		"TODAY"=>"Yellow",			// today's higlight color
		"OFFMONTH"=>"AntiqueWhite",		// off month days color
		"WEEKEND"=>"LightGray"	,		// weekend's highlight color
		"NotEmpty"=>1,
		"NotEmptyErrorMessage"=>"The START field cannot be blank",
		"CalendarIcon"=> "path/to/your/icon"	// if not found button will be displayed
	));
	 
	
	
	// pulsante di submit
	
	
	$form->AddInput(array(
		"TYPE"=>"submit",
		"NAME"=>"action",
		"Accessible"=>1,
		"ID"=>"action",
		"MAXLENGTH"=>100,
		"Capitalization"=>"uppercase",
		"VALUE"=>"Doit!",
	//	"ACCESSKEY"=>"E"
	));
	
	/*
 * Compose the form output by including a HTML form template with PHP code
 * interleaaved with calls to insert form input field
 * parts in the layout HTML.
 */

	$form->StartLayoutCapture();
	$title="Example for the date cal plugin";
	$body_template="example.html.php";
	require("classes/templates/form_frame.html.php");
 	$form->EndLayoutCapture();
	
	
	/*
	* Output the form using the function named Output.
	*/
	$form->DisplayOutput();

?>
