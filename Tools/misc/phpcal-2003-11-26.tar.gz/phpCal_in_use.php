<?php
	require("phpCal.php");
	
	if ($_GET["month"]){
		$cal = new phpCal($_GET["month"], $_GET["year"]);
		} else {
		$cal = new phpCal(date("m"), date("Y"));
		}
	
	$events = array("11/20/2003", "11/21/2003", "11/22/2003", "11/28/2003", "12/25/2003");
	$cal->setEventDays($events);
	$cal->setLinks("phpCal_in_use.php", "phpCal_in_use.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>TEST CALENDAR</title>
<style>
a {color: #993300; text-decoration: none;}
a:hover {color: #993300; text-decoration: none;}
</style>
</head>
<body>
<table width="100%" height="100%">
<tr>
<td width="100%" height="100%" align="center" valign="middle"><? print($cal->createCal()); ?></td>
</tr>
</table>
</body>
</html>
