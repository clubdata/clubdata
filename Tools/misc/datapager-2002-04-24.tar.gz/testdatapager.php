<?php

include("./datapager.php");

echo "<html>\n<head><title>Datapager Example</title></head>\n<body>\n";

// connect to some database

$conn = mysql_connect();
mysql_select_db("somedatabase");

// the name of the table to get all results from in this example

$table = "sometableinyourdatabase";

// the sql statement to query

$sql = "SELECT * FROM $table";

// create a new datapager passing it the connection and the sql

$dp = new datapager($conn, $sql);

// check to see if the page variable has been set

if( !isset( $page ) ){
	$page = 1;
}

// set the number of results to get for each page

$pagesize = 50;

// execute the query with the current page and page size and return a mysql result

$res = $dp->execute($page, $pagesize);

// if the result is valid, use it like any other mysql result to output the records

if( $res ){
	$fieldcount = mysql_num_fields($res);

	// output a header with information on the current page, number of pages and number of records

	echo "<table align=center><tr><th colspan=$fieldcount>Showing page ".$dp->page." of ".$dp->pagecount;
	echo ". Records ".((($dp->page -1)* $dp->pagesize)+1)." to ".$dp->page * $dp->pagesize." of ".$dp->recordcount."</th></tr><tr>\n";
	$fieldcount = mysql_num_fields($res);
	for( $i = 0; $i < $fieldcount; $i++){
		echo "<td align=left bgcolor='#bbbbbb'>".mysql_field_name($res, $i)."</td>\n";
	}
	echo "</tr>\n";

	// output the rows of data 

	while( $row = mysql_fetch_row($res)){
		echo "<tr>\n";
		for( $i = 0; $i < $fieldcount; $i++){
			echo "<td>".$row[$i]."</td>\n";
		}
		echo "</tr>\n";
	}

	// output a footer containing links to show previous / next and all other pages of results

	echo "<tr><td colspan=$fieldcount><table width='100%'><tr>\n";
	echo "<td width='33%' align=left>".$dp->prevpage("<a href='testdatapager.php?page=%page%'>Previous</a>\n");
	echo "</td><td width='33%' align=center>".$dp->pagelinks("<a href='testdatapager.php?page=%page%'>%page%</a>", "%page%");
	echo "</td>\n<td width='33%' align=right>".$dp->nextpage("<a href='testdatapager.php?page=%page%'>Next</a>");
	echo "</td></tr></table></td></tr></table>\n";
}else{
	echo "<h5 align=center>An error has occurred.</h5>";
}

echo "</body>\n</html>";

?>