<?php

include("./dptemplate.php");

// connect to some database

$conn = mysql_connect();
mysql_select_db("somedb");

// the name of the table to get all results from in this example

// the sql statement to query

$sql = "SELECT field1, field2, anotherfield FROM sometable";

// create a new datapager passing it the connection and the sql

$dp = new dptemplate($conn, $sql);

// check to see if the page variable has been set

if( !isset( $page ) ){
	$page = 1;
}

// set the number of results to get for each page

$pagesize = 50;

// define the templates

$header = "
<html>\n<head><title>Datapager Example</title></head>\n<body>
<h4>Viewing page <:page> of <:pagecount></h4>
<table>\n
<tr><th>Field 1 Title</th><th>Field 2 Title</th><th>Some Other Field Title</th></tr>
";

$template = "
<:row><tr><td bgcolor=yellow><:field1></td><td bgcolor=yellow><:field2></td><td bgcolor=yellow><:someotherfield></td></tr></:row>
<:row><tr><td bgcolor=green><:field1></td><td bgcolor=green><:field2></td><td bgcolor=green><:someotherfield></td></tr></:row>
";

$footer = "
<tr>
<td align=left><:prev>Previous</:prev></td>
<td align=center><:pagelinks></td>
<td align=right><:next>Next</:next></td>
</tr>
</table>
</body>
</html>
";

// execute the query with the current page and page size and return a mysql result

if( $dp->execute($page, $template, $header, $footer, $pagesize) < 1 ) echo "<h4>An error occurred.</h4>";

?>