<?php

/************************************
@ 2002 Sam Yapp www.samscripts.com

	You are free to use modify and do whatever you like with this script.

	dptemplate - this class provides a simple method of querying databases and returning specific 'page' sizes of results.
						- it uses templates to display the results for you.

	Usage:

	the constructor:

	$datapager->datapager($dbconnection, $query, $pagesize, $querytousetocountrecords);

	where:
	 $dbconnection is a connection to a mysql database
		$query is the sql query (*without any limit x, y on the end)
		$pagesize is the number of records per page
		$querytousetocountrecords is optional 
			it needs to be used when simply replaceing the fields in your queries SELECT bit with a COUNT(*) returns
			more than 1 row. (this is how datapager counts the number of records and the number of pages


		the main function - executes the query and returns a mysql result id or 0 if it fails

		$datapager->execute($page, $template, $header, $footer, $pagesize = "", $pageseparator = " | ");

	where:
		$page is the page number of results
		$template is an html template for each row of data - the format is explained below
		$header is an html template for a header to appear before the rows are output
		$footer is an html template that is displayed after the output
		$pagesize is the (optional) number or records per page
		$pageseparator is a string to use when creating a string of links to the other pages

	set up another query to execute

		$datapager->loadquery($query, $pagesize, $querytousetocountrecords); // called internally by creator function

	template format:

	each of the templates, header, footer and the main 1 are basically html with some special tags.
	In the header and the footer, the following tags can be used:

	<:page> - replaced with the page number
	<:pagesize> - replaced with the number of results per page
	<:recordcount> - replaced with the number of records in the db
	<:pagecount> - replaced with the total number of pages
	<:pagelinks> - replaced by a list of all available page numbers as links to that page
	<:next>some text here, Next would be appropriate</:next> - replaced with a link to the next page or nothing if on the last page
	<:prev>Previous page</:prev> - replaced with a link to the previous page, or nothing if already on the first page


	In the main template, you can specify that the data from one of the fields in the result is to be used by using a tag
	in the format <:fieldname>.

************************************/

// class datatemplate is a utility class used by dptemplate

class datatemplate{

	var $compiled;
	var $template;
	var $rows;
	var $cnt;
	var $rowcount;

	function converttemplate($t){
		$t = 'echo "'.preg_replace('~<:[ ]*?([a-z0-9_]+)[ ]*.*?>~is', '".$row["$1"]."', str_replace('"', '\"',$t)).'";';
		return $t;
	}

	function compiletemplate(){
		$this->rows = array();
		$found = preg_match_all('~<:row>(.*?)</:row>~is', $this->template, $temp);
		if( $found ){
			for( $i =0; $i < count($temp[1]); $i++){
				$this->rows[] = $this->converttemplate($temp[1][$i]);
			}
		}else{
			$this->rows[] = $this->converttemplate($this->template);
		}
		$this->rowcount = count($this->rows);
		$this->compiled = true;
	}

	function datatemplate($template=""){
		$this->compiled = false;
		$this->template = $template;
		$this->rows = array();
		$this->cnt = 0;
		$this->rowcount = 0;
		$this->compiletemplate();
	}

	function printrow($row){
		eval($this->rows[$this->cnt]);
		$this->cnt++;
		if( $this->cnt == $this->rowcount) $this->cnt = 0;
	}

}

class dptemplate{

	var $mainquery;
	var $countquery;
	var $results;
	var $connection;
	var $pagesize;
	var $pagecount;
	var $page;
	var $recordcount;
	var $querydone;

	function datapager($conn = 0, $query  = "", $pagesize = 10, $countquery = ""){
		$this->connection = $conn;
		$this->querydone = false;
		$this->pagesize = $pagesize;
		$this->loadquery($query, $pagesize, $countquery);
	}

	function loadquery($query, $pagesize=0, $countquery=""){
		$this->querydone = false;
		if( $pagesize > 0 )$this->pagesize = $pagesize;
		$this->results = $this->pagecount = $this->page = $this->recordcount = 0;
		if( $query == "" || strtoupper(substr($query, 0, 6)) != "SELECT") return false;
		$this->mainquery = $query;
		if( $countquery == "" ){
			$frompos = strpos( strtoupper($query), "FROM");
			$this->countquery = "SELECT COUNT(*) ".substr($query, $frompos);
		}else{
			$this->countquery = $countquery;
		}
		if( $this->connection ){
			$res = mysql_query($this->countquery, $this->connection)or die(mysql_error());
			if( $res && mysql_num_rows($res) != 1 ){
				$res = mysql_query($this->mainquery)or die(mysql_error());
				$this->recordcount = mysql_num_rows($res);
			}else{
				list($this->recordcount) = mysql_fetch_row($res);
			}
			$this->pagecount = ceil($this->recordcount / $this->pagesize);
			$this->page = 1;
			$this->querydone = true;
			mysql_free_result($res);
			return true;
		}
		return false;
	}

	function execute( $page, $template, $header="", $footer="", $pagesize = "", $pageseparator = " | "){
		if( $this->querydone == false ){
			return 0;
		}

		if( $pagesize!= "" && $pagesize > 0 ) $this->pagesize = $pagesize;
		if( $page > 0 ) $this->page = $page;

		$this->pagecount = ceil($this->recordcount / $this->pagesize);	
		if( $this->page > $this->pagecount ) $this->page = $this->pagecount;

		// do query

		$sql = $this->mainquery." LIMIT ".(($this->page-1) * $this->pagesize).",".$this->pagesize;
		$this->results = mysql_query($sql, $this->connection);

		// set up extra variables

		$extra = array("page"=>$this->page, "pagesize"=>$this->pagesize, "pagecount"=>$this->pagecount, "recordcount"=>$this->recordcount);

		global $HTTP_SERVER_VARS;
		$self = $HTTP_SERVER_VARS["PHP_SELF"];
		$q = isset($HTTP_SERVER_VARS["QUERY_STRING"]) ? $HTTP_SERVER_VARS["QUERY_STRING"] : "";

		$q = preg_replace( "~&?page=[0-9]*~i", "", $q);

		if( $q != "" ){
			$self .= "?$q&page=";
		}else{
			$self .= "?page=";
		}

		if( $this->page < $this->pagecount ){
			$header = preg_replace("~<:next>(.*?)</:next>~is", "<a href='$self".($this->page + 1)."'>\$1</a>", $header);
			$footer = preg_replace("~<:next>(.*?)</:next>~is", "<a href='$self".($this->page + 1)."'>\$1</a>", $footer);
		}else{
			$header = preg_replace("~<:next>(.*?)</:next>~is", "", $header);
			$footer = preg_replace("~<:next>(.*?)</:next>~is", "", $footer);
		}
		if( $this->page > 1 ){
			$header = preg_replace("~<:prev>(.*?)</:prev>~is", "<a href='$self".($this->page - 1)."'>\$1</a>", $header);
			$footer = preg_replace("~<:prev>(.*?)</:prev>~is", "<a href='$self".($this->page - 1)."'>\$1</a>", $footer);
		}else{
			$header = preg_replace("~<:prev>(.*?)</:prev>~is", "", $header);
			$footer = preg_replace("~<:prev>(.*?)</:prev>~is", "", $footer);
		}

		$psep = isset($args["pageseparator"]) ? $args["pageseparator"] : " | ";
		$extra["pagelinks"] = "";
		for( $i = 1; $i <= $this->pagecount; $i++){
			if( $i == $this->page ){
				$extra["pagelinks"].= $i;
			}else{
				$extra["pagelinks"] .= "<a href='$self$i'>$i</a>";
			}
			if( $i < $this->pagecount ) $extra["pagelinks"] .= $psep;
		}

		if( $this->results != 0 ){
			if( mysql_num_rows($this->results) == 0 ){
				return -1;
			}
			$dt = new datatemplate($template);
			$s = array();
			$r = array();
			while( list( $k, $v) = each( $extra)){
				$s[] = "<:$k>";
				$r[] = "$v";
			}
			echo str_replace($s, $r, $header);
			while( $row = mysql_fetch_assoc($this->results)){
		 		$dt->printrow(array_merge($row, $extra));
			}
			echo str_replace($s, $r, $footer);
		}else{
			return 0;
		}
		return 1;
	}

}

?>