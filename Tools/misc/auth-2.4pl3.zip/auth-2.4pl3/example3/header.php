<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>iCreativa User Authentication Suite: Example 2.</title>
    <link href="styles.css" rel="stylesheet" type="text/css" />
  </head>

  <body>
    <table border="0" cellspacing="0" cellpadding="2" width="600" align="center"
    class="border2px">
      <tr bgcolor="#3399CC">
        <td class="title" colspan="6">Example 2</td>
      </tr>

      <tr>
        <td width="300" bgcolor="#3399CC">&#160;</td>

        <td class="buttons"><a href="main.php">Front Page</a></td>

        <td class="buttons"><a href="admins.php">Administration</a></td>

        <td class="buttons"><a href="logout.php">Logout</a></td>
      </tr>

      <tr>
        <td colspan="6" style="padding:20px;">
