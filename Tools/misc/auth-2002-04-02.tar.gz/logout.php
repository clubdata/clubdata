<?php

require_once('./prepend.php');

$auth = &new_auth();
$auth->logout();

?>
<?php include('./header.php'); ?>
<p>Thanks for visiting us. Come back soon. If you want to really know if you
  are logged out then visit another page and see if it ask you for a
  username/password pair.</p>
<p style="color:red;"><?php print time(); ?></p>
<?php include('./footer.php'); ?>
