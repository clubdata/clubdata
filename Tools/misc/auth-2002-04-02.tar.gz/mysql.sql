DROP TABLE IF EXISTS users;
CREATE TABLE users (
    user_id INT NOT NULL AUTO_INCREMENT,

    username CHAR(32) NOT NULL,
    password CHAR(32) NOT NULL,
    email VARCHAR(255) NOT NULL,
    last_login DATETIME NOT NULL,
    fullname VARCHAR(255) NOT NULL,

    UNIQUE (username),
    UNIQUE (email),
    PRIMARY KEY(user_id)
);
INSERT INTO users (username, password, email, fullname) VALUES ('adnoctum', '0d39755ef41510da4a95cb6c9d63b92a', 'adnoctum@eudoramail.com', 'Julio C�sar Carrascal Urquijo');
INSERT INTO users (username, password, email, fullname) VALUES ('guest', '084e0343a0486ff05530df6c705c8bb4', 'guest@on.the.net', 'Guest');


DROP TABLE IF EXISTS groups;
CREATE TABLE groups (
	group_id INT NOT NULL AUTO_INCREMENT,

	name CHAR(32) NOT NULL,
	title VARCHAR(255) NOT NULL,

	UNIQUE (name),
	PRIMARY KEY(group_id)
);
INSERT INTO groups (name, title) VALUES('admin', 'Administrator');
INSERT INTO groups (name, title) VALUES('editor', 'Editor');
INSERT INTO groups (name, title) VALUES('author', 'Author');
INSERT INTO groups (name, title) VALUES('guest', 'Guest');
INSERT INTO groups (name, title) VALUES('member', 'Member');


DROP TABLE IF EXISTS users_groups;
CREATE TABLE users_groups (
	user_id INT NOT NULL,
	group_id INT NOT NULL,

	KEY user_id(group_id),
	KEY group_id(user_id)
);
INSERT INTO users_groups (user_id, group_id) VALUES (1, 1);
INSERT INTO users_groups (user_id, group_id) VALUES (1, 2);
INSERT INTO users_groups (user_id, group_id) VALUES (1, 3);
INSERT INTO users_groups (user_id, group_id) VALUES (2, 3);
INSERT INTO users_groups (user_id, group_id) VALUES (2, 4);
