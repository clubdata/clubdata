<?php

require_once('./prepend.php');

$auth = &new_auth();
$auth->securityLevel = AUTH_SECLEVEL_PRIVATE;
$auth->requireAtLeast('admin', 'author');

?>
<?php include('./header.php'); ?>
<h1>Protected page.</h1>
<p>This page, can be accessed by any user that belongs to one of the required
  groups. If you are identified as <b>guest</b> the you can see this text but
  can't enter to <a href="protected1.php">protected1.php</a>. <b>adnoctum</b>,
  on the other hand, can access everything on this site,
</p>
<h2>Code for this page:</h2>
<pre>
$auth = &amp;new_auth();
$auth-&gt;securityLevel = AUTH_SECLEVEL_PRIVATE;
$auth-&gt;requireAtLeast('admin', 'editor', 'author');
</pre>
<p style="color:red;"><?php print time(); ?></p>
<?php include('./footer.php'); ?>
