<?php

require_once('./prepend.php');

$auth = &new_auth(array('force_redirect' => true, 'redirect' => 'index.php'));
$auth->forceLogin();

?>
