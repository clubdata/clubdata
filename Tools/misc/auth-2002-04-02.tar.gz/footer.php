<ul class="navigation">
  <li><a href="index.php">Home</a></li>
  <li><a href="login.php">Login</a></li>
  <li><a href="protected1.php">requireGroups()</a></li>
  <li><a href="protected2.php">requireAtLeast()</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</body>
</html>
