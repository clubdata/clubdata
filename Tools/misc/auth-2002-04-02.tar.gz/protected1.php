<?php

require_once('./prepend.php');

$auth = &new_auth();
$auth->securityLevel = AUTH_SECLEVEL_PRIVATE;
$auth->requireGroups('admin', 'author');

?>
<?php include('./header.php'); ?>
<h1>Protected page.</h1>
<p>This page has a HIGH security level. Doesn't get saved in the
  browser cache and you have to login every time you open your
  web browser.
</p>
<h2>Code for this page:</h2>
<pre>
$auth = &amp;new_auth();
$auth-&gt;securityLevel = AUTH_SECLEVEL_PRIVATE;
$auth-&gt;requireGroups('admin', 'editor', 'author');
</pre>
<p style="color:red;"><?php print time(); ?></p>
<?php include('./footer.php'); ?>
