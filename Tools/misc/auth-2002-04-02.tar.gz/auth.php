<?php

/*
 * Auth 2.2 - User authentication managment class.
 * Copyright (C) 2002 Julio C�sar Carrascal Urquijo <adnoctum@eudoramail.com>
 *
 * This  library  is  free  software;  you can redistribute it and/or modify it
 * under  the  terms  of the GNU Library General Public License as published by
 * the  Free  Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This  library is distributed in the hope that it will be useful, but WITHOUT
 * ANY  WARRANTY;  without  even  the  implied  warranty  of MERCHANTABILITY or
 * FITNESS  FOR  A  PARTICULAR  PURPOSE.  See  the  GNU  Library General Public
 * License for more details.
 *
 * You  should  have  received a copy of the GNU Library General Public License
 * along  with  this  library;  if  not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */



if(!defined('AUTH_DIR')) define('AUTH_DIR', dirname(__FILE__));
define('AUTH_VERSION', '2.2');

/**
 * This constants identify wich action needs to take the callback function when
 * called.
 */
define('AUTH_NEED_LOGIN',    -1);	/// Need a valid username/password pair.
define('AUTH_INVALID_USER',  -2);	/// The username/password pair is invalid.
define('AUTH_ACCESS_DENIED', -3);	/// Doesn't belong to the required groups.
define('AUTH_EXPIRED',       -4);	/// The session has expired.

/**
 * Security level of the current page. This setting affects some things like the
 * allowed caching of the table, automatic authentication, etc... Default:
 * AUTH_SECLEVEL_PROTECTED. Most secure first.
 */
define('AUTH_SECLEVEL_PRIVATE',   1);	/// No cache
define('AUTH_SECLEVEL_PROTECTED', 2);	/// Cache


/**
 * User authentication component.
 */
class Auth {
//public:
	var $user = array();
	var $identified = false;
	var $securityLevel = AUTH_SECLEVEL_PROTECTED;
	var $debug = false;

	/**
	 * Database connection information for ADOdb. Consult the ADOdb readme.html
	 * file. This information is for the ADONewConnection() function and the
	 * ADOConnection::Connect() method.
	 */
	var $dbdriver = 'mysql';
	var $hostname = 'localhost';
	var $username = 'root';
	var $password = '';
	var $database = 'test';

	var $options = array(
		/**
		 * This settings should match the names of tables and fields on your
		 * database. See the examples/mysql.sql file for an example.
		 */
		'users_table' => 'users',
		'user_id_field' => 'user_id',
		'username_field' => 'username',
		'password_field' => 'password',
		'groups_table' => 'groups',
		'group_id_field' => 'group_id',
		'group_name_field' => 'name',
		'users_groups_table' => 'users_groups',

		/**
		 * This settings affect the way the session is handled by PHP. See
		 * http://www.php.net/session for an explanation of each one.
		 */
		/// Time the cookie will live in your users' cache.
		'cookie_lifetime' => 2592000,	// one month.
		/// Path for wich the cookie will be valid.
		'cookie_path' => '/',
		/// Owner domain of the cookie.
		'cookie_domain' => null,
		// Name of the session cookie.
		'session_name' => 'AUTHSESSID',
		// Name of the session variable.
		'session_variable' => 'user',

		/// Maximum time a user has to make a new request.
		'expires' => 1800,	// half hour.
		// redirect the request to the specified page (this page by default).
		'force_redirect' => false,
		'redirect' => null,
	);


	/**
	 * Constructor.
	 *
	 * @param $options	array, key => val.
	 */
	function Auth($options = null) {
		if(!isset($_SERVER)) {	// PHP 4.0.x
			$_SERVER = &$GLOBALS['HTTP_SERVER_VARS'];
		}
		$this->options['redirect'] = $_SERVER['PHP_SELF'];
		$this->options = array_merge($this->options, (array)$options);
		$this->user = array();
	}


	/**
	 * Utility function called implicitly when needed.
	 */
	function startSession() {
		if(!isset($_SESSION)) {	// PHP 4.0.x
			$_SESSION = &$GLOBALS['HTTP_SESSION_VARS'];
		}
		if($this->securityLevel == AUTH_SECLEVEL_PROTECTED) {
			session_cache_limiter('private, must-revalidate');
			header('Cache-Control: private, must-revalidate');
		} else {
			session_cache_limiter('no-cache, must-revalidate');
			header('Cache-Control: no-cache, must-revalidate');
		}

		// Start the session.
		if(preg_match('!^\w+$!', $this->options['session_name']))
			session_name($this->options['session_name']);
		$GLOBALS[$this->options['session_variable']] = null;	// paranoia.
		session_set_cookie_params(0, $this->options['cookie_path'],
			$this->options['cookie_domain']);
		session_register($this->options['session_variable']);
		if(isset($_SESSION[$this->options['session_variable']]))
			$this->user = &$_SESSION[$this->options['session_variable']];

		$this->identified = $this->_checkSession();
	}


	/**
	 * Force the user to identify him self.
	 */
	function forceLogin() {
		if(!isset($_POST)) {	// PHP 4.0.x
			$_POST = &$GLOBALS['HTTP_POST_VARS'];
			$_SERVER = &$GLOBALS['HTTP_SERVER_VARS'];
			$_SESSION = &$GLOBALS['HTTP_SESSION_VARS'];
		}
		$this->startSession();

		if(!$this->identified) {
			if(isset($_POST[$this->options['username_field']])) {
				$user = $this->_findByUsername(
					$_POST[$this->options['username_field']],
					$_POST[$this->options['password_field']]);
				$user_id = $user[$this->options['user_id_field']];
				$user['groups'] = $this->_getGroups($user_id);

				// Update session.
				$user['::last_login::'] = time();

				// Save session.
				$_SESSION[$this->options['session_variable']] = $user;
				$this->user = &$_SESSION[$this->options['session_variable']];

			} else {
				$this->_callback(AUTH_NEED_LOGIN,
					'A valid username/password pair is needed.');
			}
		}
		// Redirect if requested.
		if(($_SERVER['REQUEST_METHOD'] == 'POST' ||
			$this->options['force_redirect']) &&
			$this->options['redirect'] !== null) {
			header('Location: '.$this->options['redirect']);
			exit();
		}
	}


	/**
	 * Force the user to identify himself (If he hasn't do it before) and
	 * ensures that he belongs to each specified group. You can pass all the
	 * groups you need at once.
	 *
	 * @param $group1, ...	name of each required group.
	 * @see #requireAtLeast
	 */
	function requireGroups() {
		$this->startSession();

		if(!$this->identified)
			$this->forceLogin();

		// check each group.
		$groups = func_get_args();
		foreach($groups as $group) {
			if(!isset($this->user['groups'][$group]) ||
				!$this->user['groups'][$group]) {
				$this->_callback(AUTH_ACCESS_DENIED,
					'You are not allowed to access this zone.');
			}
		}
	}


	/**
	 * Force the user to identify himself (If he hasn't do it before) and
	 * ensures that he belongs "at least" to one of the specified groups. You
	 * can pass all the groups you need at once.
	 *
	 * @param $group1, ...	name of each required group.
	 * @see #requireGroups
	 */
	function requireAtLeast() {
		$this->startSession();

		if(!$this->identified)
			$this->forceLogin();

		// we need at least one group.
		$autorized = false;
		$groups = func_get_args();
		foreach($groups as $group) {
			if(isset($this->user['groups'][$group]) &&
				$this->user['groups'][$group]) {
				$autorized = true;
			}
		}
		if(!$autorized) {
			call_user_func(AUTH_CALLBACK, AUTH_ACCESS_DENIED,
				'You are not allowed to access this zone.');
		}
	}


	/**
	 * Delete all session information and logout the user.
	 */
	function logout() {
		if(!isset($_SESSION)) {	// PHP 4.0.x
			$_SESSION = &$GLOBALS['HTTP_SESSION_VARS'];
		}
		$this->forceLogin();
		//$this->startSession();
		$GLOBALS[$this->options['session_variable']] = null;	// paranoia.
		unset($_SESSION[$this->options['session_variable']]);	// more paranoia
		session_destroy();
		$this->user = array();
	}


	/**
	 * Updates the user's information. The user must be identified already.
	 * Usefull if you just updated the database and you need to update your
	 * session variable. If an error occurs this function, for security reasons,
	 * ends the execution of the script.
	 */
	function refreshInfo() {
		if(!isset($_SESSION)) {	// PHP 4.0.x
			$_SESSION = &$GLOBALS['HTTP_SESSION_VARS'];
		}
		if(!$this->identified)
			$this->forceLogin();

		$user_id = $this->user[$this->options['user_id_field']];
		$_SESSION[$this->options['session_variable']] =
			$this->_findById($user_id);
		$_SESSION[$this->options['session_variable']]['groups'] =
			$this->_getGroups($user_id);
		$this->user = &$_SESSION[$this->options['session_variable']];
	}


//protected:
	var $_conn = null;

	/**
	 * Just calls the callback function and dies. This function doesn't returns.
	 *
	 * @param $action	int, What action should the callback function take. Has
	 *                  to be one of AUTH_NEED_LOGIN, AUTH_INVALID_USER,
	 *                  AUTH_ACCESS_DENIED or AUTH_EXPIRED
	 * @param $message	optional, string, message to show to the user.
	 */
	function _callback($action, $message = '') {
		// include the default callback function.
		if(!defined('AUTH_CALLBACK'))
			include_once(AUTH_DIR.'/auth_callback.php');
		call_user_func(AUTH_CALLBACK, $action, $message, $this);
		die();
	}


	/**
	 * Connect to the database only if necesary.
	 */
	function _connect() {
		if($this->_conn === null) {
			$this->_conn = &ADONewConnection($this->dbdriver);
			if($this->debug) {
				$this->_conn->debug = $this->debug;
				ob_start();
			}
			if($this->_conn === null) {
				trigger_error($this->dbdriver.' is not supported',
					E_USER_ERROR);
			}
			$res = $this->_conn->Connect($this->hostname,
				$this->username, $this->password, $this->database);
			if($res === false) {
				trigger_error('Can\'t connect to '.$this->options['hostname'],
					E_USER_ERROR);
				die();	// paranoia.
			}
		}
	}

	/**
	 * Search the user in the database by his username and password.
	 *
	 * @param $username
	 * @param $password
	 * @return array, users information.
	 * @see #_findById
	 */
	function _findByUsername($username, $password) {
		$this->_connect();

		$user = array();
		$sql = sprintf('SELECT * FROM %s WHERE %s = %s AND %s = %s',
			$this->options['users_table'], $this->options['username_field'],
			$this->_conn->qstr($username, get_magic_quotes_gpc()),
			$this->options['password_field'],
			$this->_conn->qstr(md5($password), get_magic_quotes_gpc()));
		$rs = $this->_conn->Execute($sql);
		if($rs === null || $rs->EOF) {
			$this->_callback(AUTH_INVALID_USER,
				"Can't find the user's information in the database");
		} else {
			$user =	$rs->GetRowAssoc(false);
			$user['::last_login::'] =
				$rs->UnixTimestamp($user['::last_login::']);
		}
		return $user;
	}

	/**
	 * Search the user in the database by his user_id field.
	 *
	 * @param $user_id
	 * @return array, users information.
	 * @see #_findByUsername
	 */
	function _findById($user_id) {
		$this->_connect();

		$user = array();
		$sql = sprintf('SELECT * FROM %s WHERE %s = %s',
			$this->options['users_table'], $this->options['user_id_field'],
			$user_id);
		$rs = $this->_conn->Execute($sql);
		if($rs === false || $rs->EOF) {
			$this->_callback(AUTH_INVALID_USER,
				"Can't find the user's information in the database");
		} else {
			$user = $rs->GetRowAssoc(false);
			$user['::last_login::'] =
				$rs->UnixTimestamp($user['::last_login::']);
		}
		return $user;
	}


	/**
	 * Search the groups a user belongs to and returns an associative array for
	 * easy access.
	 *
	 * @param $user_id
	 * @return array('group1' => true, 'group2' => true);
	 */
	function _getGroups($user_id) {
		$this->_connect();

		$groups = array();
		$sql = sprintf('SELECT groups.%s FROM %s groups, %s users_groups '.
			'WHERE users_groups.%s = %s AND groups.%s = users_groups.%s',
			$this->options['group_name_field'], $this->options['groups_table'],
			$this->options['users_groups_table'],
			$this->options['user_id_field'], $user_id,
			$this->options['group_id_field'], $this->options['group_id_field']);
		$rs = $this->_conn->Execute($sql);
		if($rs === false) {
			trigger_error('SQL Syntax error when reading the user\'s groups.',
				E_USER_ERROR);
			die();
		} else {
			for(; !$rs->EOF; $rs->MoveNext())
				$groups[$rs->fields[0]] = true;
		}
		return $groups;
	}


	/**
	 * Validates the current session.
	 *
	 * @return bool
	 */
	function _checkSession() {
		$identified = false;
		if(isset($this->user[$this->options['user_id_field']])) {
			$user_id = $this->user[$this->options['user_id_field']];
			$last_login = $this->user['::last_login::'];
			$time = time();
			if(($last_login + $this->options['expires']) < $time) {
				$this->_callback(AUTH_EXPIRED, 'Your session just expired');
			} else {
				$this->user['::last_login::'] = $time;
				$identified = true;
			}
		}
		return $identified;
	}
}


?>
