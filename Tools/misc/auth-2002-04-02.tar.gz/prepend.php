<?php

require_once('../adodb/adodb.inc.php');
require_once('auth.php');

function &new_auth($options = null) {
	$dbdriver = 'mysql';
	$hostname = 'localhost';
	$username = 'root';
	$password = '';
	$database = 'test';

	$auth = new Auth($options);
	$auth->dbdriver = $dbdriver;
	$auth->hostname = $hostname;
	$auth->username = $username;
	$auth->password = $password;
	$auth->database = $database;

	return $auth;
}
?>
