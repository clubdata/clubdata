<?php

define('AUTH_CALLBACK', 'auth_callback');

function auth_callback($action, $message = '', &$auth) {
	global $HTTP_SERVER_VARS;
	/* If you want to log your authentication trafic set $logging to true. and
	 * set the corresponding variables according to http://www.php.net/error_log
	 */
	$logging = false;
	$logType = 0;
	$logDest = '';
	$logHeaders = '';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<header>
<title>Authentication.</title>
<style type="text/css">
/*<![CDATA[*/
body{background:#FFF;font:10pt Verdana,Helvetica,sans-serif;}
p,td,li{font:8pt Verdana,Helvetica,sans-serif;}
.content{background:#EEE;border:1px solid #CCC;width:450px;}
.content .title{background:white;border:1px solid #CCC; color:#369;font:bold 12pt Verdana,Helvetica,sans-serif;padding:10px;}
.content th{background:#BDE;border:1px solid #ABD;font:bold 10pt Verdana,Helvetica,sans-serif;}
.content td{text-align:center;}
.content .text{background:#DDD;border:1px inset #CCC;font:8pt Verdana,Helvetica,sans-serif;width:200px;}
.content .button{background:#DDD;border:1px outset #CCC;font:8pt Verdana,Helvetica,sans-serif;padding:2px 4px 2px 4px;}
/*]]>*/
</style>
</header>
<body>
<table align="center" class="content" cellspacing="10">
<tr><td class="title" colspan="2"><?php echo $message; ?></td></tr>
<?php

	switch($action) {
		case AUTH_NEED_LOGIN:
		global $HTTP_SERVER_VARS;
		echo '<form action="'.htmlentities($HTTP_SERVER_VARS['PHP_SELF']).'" method="post">';
		echo '<tr><th>Username:</th><td><input class="text" name="'.$auth->options['username_field'].'" type="text" maxlength="32"/></td>';
		echo '<tr><th>Password:</th><td><input class="text" name="'.$auth->options['password_field'].'" type="password"/></td>';
		echo '<tr><td colspan="2">To access this zone you need to provide a valid username/password pair. ';
		echo 'If you lost your account info you can use our <a href="/lostpassword.php">reset password</a> form to access your account again.</td></tr>';
		echo '<tr><td colspan="2"><input class="button" type="submit" value="Login"/> <input class="button" onclick="history.go(-1);" type="button" value="Cancel"/></td></tr>';
		echo '</form>';
		break;

		case AUTH_INVALID_USER:
		echo '<form action="'.$HTTP_SERVER_VARS['PHP_SELF'].'" method="post">';
		echo '<tr><th>Username:</th><td><input class="text" name="'.$auth->options['username_field'].'" type="text" maxlength="32"/></td>';
		echo '<tr><th>Password:</th><td><input class="text" name="'.$auth->options['password_field'].'" type="password"/></td>';
		echo '<tr><td colspan="2">Your account doesn\'t exists. Please correct your information. ';
		echo 'If you lost your account info you can use our <a href="/lostpassword.php">reset password</a> form to access your account again.</td></tr>';
		echo '<tr><td colspan="2"><input class="button" type="submit" value="Login"/> <input class="button" onclick="history.go(-1);" type="button" value="Cancel"/></td></tr>';
		echo '</form>';
		break;

		case AUTH_EXPIRED:
		echo '<tr><td colspan="2">Your session just expired. Please login again.</td></tr>';
		echo '<form action="'.$HTTP_SERVER_VARS['PHP_SELF'].'" method="post">';
		echo '<tr><th>Username:</th><td><input class="text" name="'.$auth->options['username_field'].'" type="text" maxlength="32"/></td>';
		echo '<tr><th>Password:</th><td><input class="text" name="'.$auth->options['password_field'].'" type="password"/></td>';
		echo '<tr><td colspan="2">To access this zone you need to provide a valid username/password pair. ';
		echo 'If you lost your account info you can use our <a href="/lostpassword.php">reset password</a> form to access your account again.</td></tr>';
		echo '<tr><td colspan="2"><input class="button" type="submit" value="Login"/> <input class="button" onclick="history.go(-1);" type="button" value="Cancel"/></td></tr>';
		echo '</form>';
		break;

		case AUTH_ACCESS_DENIED:
		default:
		echo '<tr><td>Your don\'t have access to this zone. Please leave it now!.</td>';
		echo '<tr><td><input class="button" onclick="history.go(-1);" type="button" value="Exit"/></td></tr>';
		break;
	}

?></div>
</table>
</body>
</html><pre>
<?php
	if($logging) {
		error_log("AUTH ERROR: $message", logType, $logDest,
			$logHeaders);
	}
}

?>
