<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Authentication.</title>
<link href="styles.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<ul class="navigation">
  <li><a href="index.php">Home</a></li>
  <li><a href="login.php">Login</a></li>
  <li><a href="protected1.php">requireGroups()</a></li>
  <li><a href="protected2.php">requireAtLeast()</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
