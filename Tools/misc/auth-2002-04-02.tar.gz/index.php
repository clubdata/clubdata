<?php

require_once('./prepend.php');

$auth = &new_auth();
$auth->startSession();

?>
<?php include('./header.php'); ?>
<h1>This is an unprotected page.</h1>
<?php if(!$auth->identified) { ?>
<p>You aren't logged in, but that's not a problem here because this page doesn't
have any sensible information.</p>
<p>To test the class you can go to the <a href="login.php">login page</a> and
access the system using this account: <code>adnoctum/adnoctum</code>. There is
another account: <code>guest/guest</code> that only belongs to "guest" group.
See the <a href="mysql.sql">mysql.sql</a> file for an example.</p>
<?php } else { ?>
<p>Hi, again. You are back to the index.php page. As you are logged in I can
show you a customized version of this page. You like arrays, don't you? This is
the information I have about you in the session:</p>
<pre><?php print_r($auth->user); ?></pre>
<p>This page should be saved in your cache now. To make sure thats so, check the
number at the bottom of the page, click another button in the navigation bar at
the top of the page and then hit the back button on your browser. If the number
is the same you check last time then the cache is working.</p>
<p style="color:red;"><?php print time(); ?></p>
<?php } ?>
<?php include('./footer.php'); ?>
